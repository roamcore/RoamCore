DOMAIN = "roamcore"

CONF_CONTRACT_VERSION = "contract_version"
DEFAULT_CONTRACT_VERSION = 1

# Options
CONF_OPENCLAW_API_ENABLED = "openclaw_api_enabled"
CONF_OPENCLAW_API_REQUIRES_AUTH = "openclaw_api_requires_auth"

DEFAULT_OPENCLAW_API_ENABLED = True
# MVP: default unauthenticated for isolated LAN use. Users can harden via options.
DEFAULT_OPENCLAW_API_REQUIRES_AUTH = False

# Setup wizard / optional integrations (stored in config entry options)
CONF_TRACCAR_USER_TOKEN = "traccar_user_token"
CONF_IOVERLANDER_API_KEY = "ioverlander_api_key"

CONF_AUTO_PROVISION_ASSETS = "auto_provision_assets"
DEFAULT_AUTO_PROVISION_ASSETS = True
CONF_PROVISION_REF = "provision_ref"
DEFAULT_PROVISION_REF = "main"
