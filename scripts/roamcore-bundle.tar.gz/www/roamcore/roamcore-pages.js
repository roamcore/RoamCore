// RoamCore Pages (v0) - Power + Network subpages as custom Lovelace cards
// Goal: translate v0/lovable TSX pages into HAOS without depending on HA default card styling.
// Naming convention reference: RoamCore/docs/reference/rc-entity-naming.md

function rcStatusToColor(status) {
  if (status === 'good') return 'var(--rc-good)';
  if (status === 'ok') return 'var(--rc-ok)';
  if (status === 'bad') return 'var(--rc-bad)';
  if (status === 'inactive') return 'var(--rc-inactive)';
  return 'var(--rc-muted)';
}

function rcStatusLabel(status) {
  if (status === 'good') return 'Healthy';
  if (status === 'ok') return 'OK';
  if (status === 'bad') return 'Poor';
  if (status === 'inactive') return 'Inactive';
  return '—';
}

function rcCap(s) {
  if (!s) return '—';
  return String(s).charAt(0).toUpperCase() + String(s).slice(1);
}

function rcPowerStatusFromSoc(soc) {
  if (soc == null) return 'ok';
  if (soc >= 60) return 'good';
  if (soc >= 30) return 'ok';
  return 'bad';
}

function rcLevelStatusFromPitchRoll(pitch, roll) {
  const pv = (pitch==null||pitch!=pitch) ? 0 : Math.abs(Number(pitch));
  const rv = (roll==null||roll!=roll) ? 0 : Math.abs(Number(roll));
  const v = Math.max(pv, rv);
  if (!isFinite(v)) return { label: '—', status: 'inactive' };
  if (v < 2) return { label: 'Level', status: 'good' };
  if (v < 6) return { label: 'Slight Tilt', status: 'ok' };
  return { label: 'Not Level', status: 'bad' };
}

function rcIsMissingState(v) {
  const s = (v === undefined || v === null) ? '' : String(v);
  const t = s.toLowerCase();
  return !s || t === 'unknown' || t === 'unavailable' || t === 'none';
}

// Demo values are only used when input_boolean.rc_demo_mode is ON and the real
// entity state is missing/unknown/unavailable.
const RC_DEMO_STATES = {
  // Power
  'sensor.rc_power_battery_soc': '83',
  'sensor.rc_power_solar_power': '420',
  'sensor.rc_power_load_power': '280',
  'sensor.rc_power_battery_voltage': '12.7',
  'sensor.rc_power_battery_current': '-22',
  'sensor.rc_power_battery_temperature': '24.5',
  'binary_sensor.rc_power_shore_connected': 'off',
  'sensor.rc_power_inverter_status': 'on',

  // Network
  'sensor.rc_net_wan_status': 'good',
  'sensor.rc_net_wan_source': 'cellular',
  'sensor.rc_net_download': '47',
  'sensor.rc_net_upload': '9',
  'sensor.rc_net_ping': '43',
  'sensor.rc_net_cellular_provider': 'DemoTel',
  'sensor.rc_net_cellular_technology': '5G',
  'sensor.rc_net_cellular_signal': '-85',
  'sensor.rc_net_ssid': 'RoamCore-Demo',
  'sensor.rc_net_channel': '36',

  // Location
  'sensor.rc_location_lat': '37.7749',
  'sensor.rc_location_lon': '-122.4194',
  'sensor.rc_location_accuracy_m': '12',
  'sensor.rc_location_accuracy': '12',
  'sensor.rc_location_speed': '0',
  'sensor.rc_location_heading_deg': '0',
  'sensor.rc_location_source': 'demo',

  // Level
  'sensor.rc_system_level_pitch_deg': '0.8',
  'sensor.rc_system_level_roll_deg': '-1.2',
  'sensor.rc_system_level_pitch': '0.8',
  'sensor.rc_system_level_roll': '-1.2',

  // Trip Wrapped (light preview)
  'sensor.rc_trip_distance_today_mi': '54',
  'sensor.rc_trip_time_today': '1h 42m',
};

function rcVanSideSvg() {
  return `
    <svg viewBox="0 0 80 40" class="rc-van">
      <g fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
        <path d="M8 30 L8 18 L20 18 L28 10 L68 10 L68 30" />
        <path d="M28 10 L28 18 L68 18" />
        <rect x="30" y="12" width="8" height="5" rx="0.5" />
        <rect x="42" y="12" width="8" height="5" rx="0.5" />
        <rect x="54" y="12" width="10" height="5" rx="0.5" />
        <line x1="40" y1="18" x2="40" y2="30" />
        <path d="M14 30 A6 6 0 0 1 26 30" />
        <path d="M54 30 A6 6 0 0 1 66 30" />
      </g>
      <circle cx="20" cy="32" r="4" fill="rgba(255,255,255,0.25)" />
      <circle cx="60" cy="32" r="4" fill="rgba(255,255,255,0.25)" />
    </svg>
  `;
}

function rcVanBackSvg() {
  return `
    <svg viewBox="0 0 50 45" class="rc-van">
      <g fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
        <rect x="6" y="8" width="38" height="28" rx="2" />
        <line x1="25" y1="12" x2="25" y2="36" />
        <rect x="10" y="12" width="11" height="8" rx="0.5" />
        <rect x="29" y="12" width="11" height="8" rx="0.5" />
        <rect x="8" y="28" width="3" height="6" rx="0.5" />
        <rect x="39" y="28" width="3" height="6" rx="0.5" />
      </g>
      <circle cx="10" cy="39" r="3.5" fill="rgba(255,255,255,0.25)" />
      <circle cx="40" cy="39" r="3.5" fill="rgba(255,255,255,0.25)" />
    </svg>
  `;
}

function rcMiniMapSvg() {
  return `
    <svg viewBox="0 0 100 60" class="rc-map" preserveAspectRatio="none">
      <defs>
        <pattern id="grid" width="12" height="12" patternUnits="userSpaceOnUse">
          <path d="M 12 0 L 0 0 0 12" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="1" />
        </pattern>
      </defs>
      <rect width="100" height="60" fill="url(#grid)" />
      <path d="M10 50 Q 30 30, 50 35 T 90 15" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="2" stroke-dasharray="4 2" />
      <circle cx="90" cy="15" r="4" fill="var(--rc-good)" />
    </svg>
  `;
}

class RoamcoreBasePage extends HTMLElement {
  setConfig(config) {
    this._config = config || {};
    if (!this._root) {
      this.attachShadow({ mode: 'open' });
      this._root = document.createElement('div');
      this.shadowRoot.appendChild(this._root);
      const style = document.createElement('style');
      style.textContent = this._css();
      this.shadowRoot.appendChild(style);

      // delegated nav handler (bind once)
      this._rcNavBound = true;
      this._root.addEventListener('click', (ev) => {
        const path = ev.composedPath ? ev.composedPath() : [];
        const candidates = path.length ? path : [ev.target];
        for (const node of candidates) {
          if (node && node.getAttribute) {
            // Universal “more info” popup (native HA dialog w/ history + settings)
            const more = node.getAttribute('data-more');
            if (more) {
              try {
                ev.preventDefault();
                ev.stopPropagation();
              } catch (e) {}
              this._openMoreInfo(more);
              return;
            }
            // Service call helper (e.g. toggle demo mode)
            const call = node.getAttribute('data-call');
            if (call) {
              try {
                const parts = String(call).split('.');
                const domain = parts[0] || '';
                const service = parts[1] || '';
                const entityId = node.getAttribute('data-entity') || '';
                if (domain && service && entityId) {
                  this._callService(domain, service, { entity_id: entityId });
                  return;
                }
              } catch (e) {}
            }
            const nav = node.getAttribute('data-nav');
            if (nav) {
              this._navigate(nav);
              return;
            }
          }
        }
      });
    }
    this._render();
  }

  set hass(hass) {
    this._hass = hass;
    this._render();
  }

  _openMoreInfo(entityId) {
    try {
      if (!entityId) return;
      // Home Assistant expects a CustomEvent with `detail.entityId`.
      const ev = new CustomEvent('hass-more-info', {
        bubbles: true,
        composed: true,
        detail: { entityId: String(entityId) },
      });
      this.dispatchEvent(ev);
    } catch (e) {}
  }

  _callService(domain, service, data = {}) {
    try {
      if (!this._hass || typeof this._hass.callService !== 'function') return;
      this._hass.callService(domain, service, data);
    } catch (e) {}
  }

  _isDemoMode() {
    try {
      return this._hass?.states?.['input_boolean.rc_demo_mode']?.state === 'on';
    } catch (e) {
      return false;
    }
  }

  _setupState() {
    // Wizard tiles (Bernard): Power / Network / Level / Map.
    const power = this._hass?.states?.['binary_sensor.rc_setup_victron_ready']?.state;
    const net = this._hass?.states?.['binary_sensor.rc_setup_networking_ready']?.state;
    const lvl = this._hass?.states?.['binary_sensor.rc_setup_levelling_ready']?.state;
    const map = this._hass?.states?.['binary_sensor.rc_setup_map_ready']?.state;

    // Extra readiness bits (not tiles but still useful to surface).
    const owner = this._hass?.states?.['binary_sensor.rc_setup_owner_ready']?.state;
    const trip = this._hass?.states?.['binary_sensor.rc_setup_trip_wrapped_ready']?.state;
    const progress = this._hass?.states?.['sensor.rc_setup_progress']?.state;
    const ok = (v) => String(v || '').toLowerCase() === 'on';

    const tileDone = (ok(power) ? 1 : 0) + (ok(net) ? 1 : 0) + (ok(lvl) ? 1 : 0) + (ok(map) ? 1 : 0);
    const tileTotal = 4;
    const complete = tileDone === tileTotal;
    const enabled = (
      !rcIsMissingState(power) || !rcIsMissingState(net) || !rcIsMissingState(lvl) || !rcIsMissingState(map) ||
      !rcIsMissingState(owner) || !rcIsMissingState(trip) || !rcIsMissingState(progress)
    );
    return {
      enabled,
      complete,
      progress,
      tileDone,
      tileTotal,
      powerOk: ok(power),
      netOk: ok(net),
      levelOk: ok(lvl),
      mapOk: ok(map),
      // extra
      ownerOk: ok(owner),
      tripOk: ok(trip),
    };
  }

  _setupBanner() {
    try {
      const st = this._setupState();
      if (!st.enabled) return '';
      if (st.complete) return '';

      const prog = (!rcIsMissingState(st.progress)) ? String(st.progress) : '';
      const bits = [
        st.powerOk ? null : 'Power',
        st.netOk ? null : 'Network',
        st.levelOk ? null : 'Level',
        st.mapOk ? null : 'Map',
      ].filter(Boolean);
      const missing = bits.length ? bits.join(', ') : '—';

      const demo = this._isDemoMode();
      const demoPill = demo
        ? `<span class="rc-pill rc-pill-demo">Demo mode</span>`
        : '';

      return `
        <div class="rc-setup-banner">
          <div class="rc-setup-top">
            <div>
              <div class="rc-setup-title">Setup not complete</div>
              <div class="rc-setup-sub">Tiles: <b>${st.tileDone}/${st.tileTotal}</b>${prog ? ` · Overall: <b>${prog}</b>` : ''} · Missing: <b>${missing}</b></div>
            </div>
            <div class="rc-setup-right">${demoPill}</div>
          </div>
          <div class="rc-setup-actions">
            <button class="rc-btn rc-btn-small" data-nav="${this._basePath()}/setup">Open setup wizard</button>
            <button class="rc-btn rc-btn-small" data-nav="${this._basePath()}/settings">Dashboard settings</button>
          </div>
        </div>
      `;
    } catch (e) {
      return '';
    }
  }

  _getState(id) {
    const raw = this._hass?.states?.[id]?.state;
    if (this._isDemoMode() && rcIsMissingState(raw) && RC_DEMO_STATES[id] !== undefined) {
      return RC_DEMO_STATES[id];
    }
    return raw;
  }

  _num(id, fallback = null) {
    const n = Number(this._getState(id));
    return Number.isFinite(n) ? n : fallback;
  }

  _tileUrl() {
    // Prefer a configurable tile URL so we can support offline/local tiles.
    // Set via HA Helper: input_text.rc_map_tile_url
    // Example local/offline tile server:
    //   http://homeassistant.local:8123/local/tiles/{z}/{x}/{y}.png
    const v = this._getState('input_text.rc_map_tile_url');
    if (v && v !== 'unknown' && v !== 'unavailable' && String(v).trim()) {
      return String(v).trim();
    }
    // Default: RoamCore local offline tile endpoint.
    return '/rc-tiles/{z}/{x}/{y}.png';
  }

  _mapStyleUrl() {
    // Optional MapLibre style URL (vector).
    // Set via HA Helper: input_text.rc_map_style_url
    const v = this._getState('input_text.rc_map_style_url');
    if (v && v !== 'unknown' && v !== 'unavailable' && String(v).trim()) {
      return String(v).trim();
    }

    // Default (beta): online CARTO raster tiles in a clean MapLibre style.
    // We intentionally avoid tile.openstreetmap.org here because it does not
    // send CORS headers required for WebGL textures, which makes MapLibre
    // render blank/grey.
    return '/local/roamcore/styles/rc-online-carto-light.json';
  }

  _maplibreMaxZoom(styleUrl, lat, lon) {
    // Beta: online-only style.
    return 19;
  }

  _mapMode() {
    const styleUrl = this._mapStyleUrl();

    // Prefer MapLibre only when explicitly configured; otherwise use Leaflet raster.
    if (styleUrl) return { mode: 'maplibre', styleUrl };
    return { mode: 'leaflet', tileUrl: this._tileUrl() };
  }

  // NOTE: Offline PMTiles support removed for Beta (online-only map).

  _onlineTileUrl() {
    // Optional online tile URL for detailed view when internet is available.
    // Set via HA Helper: input_text.rc_map_tile_url_online
    // Default OFF (empty) to keep the map fully offline unless explicitly enabled.
    const v = this._getState('input_text.rc_map_tile_url_online');
    if (v && v !== 'unknown' && v !== 'unavailable' && String(v).trim()) {
      return String(v).trim();
    }
    return '';
  }

  _offlineMaxZoom() {
    // Max zoom level with offline tile coverage. Above this, online tiles are used.
    // Adjust based on how much you've preloaded.
    const v = this._getState('input_number.rc_map_offline_max_zoom');
    const n = Number(v);
    return Number.isFinite(n) ? n : 6;
  }

  _navigate(path) {
    try {
      if (!path) return;
      if (this._hass && typeof this._hass.navigate === 'function') {
        this._hass.navigate(path);
        return;
      }
      history.pushState(null, '', path);
      window.dispatchEvent(new Event('location-changed'));
    } catch (e) {
      console.warn('roamcore navigate failed', e);
    }
  }

  // Legacy hook (some pages still call this even though navigation is delegated).
  _wireNav() {}

  _basePath() {
    // The RoamCore dashboard can be mounted at different base paths depending on
    // whether it's a YAML dashboard or a storage dashboard.
    // Common patterns we've used:
    //   - /roam-core/...   (YAML dashboard id must include a hyphen)
    //   - /roamcore/...    (legacy)
    //   - /lovelace/roamcore/... (storage dashboard)
    try {
      const p = String(window.location?.pathname || '');
      if (p.startsWith('/roam-core/')) return '/roam-core';
      if (p === '/roam-core') return '/roam-core';
      if (p.startsWith('/roamcore/')) return '/roamcore';
      if (p === '/roamcore') return '/roamcore';
      if (p.startsWith('/lovelace/roamcore/')) return '/lovelace/roamcore';
      if (p === '/lovelace/roamcore') return '/lovelace/roamcore';
    } catch (e) {}
    // Safe default: if we can't tell, fall back to the YAML dashboard id.
    return '/roam-core';
  }

  _header(title) {
    return `
      <div class="rc-subheader">
        <button class="rc-back" data-nav="${this._basePath()}/home">←</button>
        <div class="rc-subtitle">${title}</div>
        <div class="rc-subspacer"></div>
        <button class="rc-gear" title="Settings" data-nav="${this._basePath()}/settings">⚙</button>
      </div>
      ${this._setupBanner()}
    `;
  }

  _traccarEmbedUrl() {
    // Prefer HA Supervisor ingress panel so it works from mobile app / remote access.
    // Direct LAN URLs (e.g. :8082) can be blocked as "public page -> local network".
    try {
      const panels = this._hass?.panels || {};
      for (const key of Object.keys(panels)) {
        const p = panels[key];
        const title = String(p?.title || p?.config?.title || '').toLowerCase();
        const urlPath = p?.url_path || '';
        if (title.includes('traccar') || urlPath.includes('traccar')) {
          // url_path is already a frontend route.
          return `/${urlPath}`;
        }
      }
    } catch (e) {
      // ignore
    }
    // Fallback: same-origin HA proxy (frontend route; works in iframes)
    return '/api/roamcore/traccar_public/';
  }

  _tile({ title, icon, content, className = '' }) {
    return `
      <div class="rc-dtile ${className}">
        <div class="rc-dtile-head">
          <div class="rc-dtile-title">${title}</div>
          <div class="rc-dtile-icon">${icon || ''}</div>
        </div>
        <div class="rc-dtile-body">${content}</div>
      </div>
    `;
  }

  _row(label, value, unit = '', color = '', moreEntityId = '') {
    const v = (value === null || value === undefined || value === '' || value === 'unknown' || value === 'unavailable') ? '—' : value;
    const style = color ? ` style="color:${color}"` : '';
    const more = (moreEntityId && String(moreEntityId).trim()) ? ` data-more="${String(moreEntityId).trim()}"` : '';
    const unitHtml = unit ? `<span class="rc-unit">${unit}</span>` : '';
    return `
      <div class="rc-row">
        <div class="rc-label">${label}</div>
        <div class="rc-val"${style}${more}>${v}${unitHtml}</div>
      </div>
    `;
  }

  _badge(label, status) {
    const c = rcStatusToColor(status);
    return `
      <div class="rc-badge" style="border-color:${c}; background: color-mix(in srgb, ${c} 18%, transparent)">
        <span class="rc-bdot" style="background:${c}"></span>
        <span class="rc-btxt" style="color:${c}">${label}</span>
      </div>
    `;
  }

  _batterySvg(percent, fillColor) {
    const p = Math.max(0, Math.min(100, Number(percent) || 0));
    const fillW = (p / 100) * 44;
    return `
      <svg viewBox="0 0 56 28" class="rc-batt2">
        <rect x="1" y="4" width="48" height="20" rx="2" fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="2"/>
        <rect x="49" y="9" width="5" height="10" rx="1" fill="rgba(255,255,255,0.25)"/>
        <rect x="3" y="6" width="${fillW}" height="16" rx="1" fill="${fillColor}"/>
      </svg>
    `;
  }

  _css() {
    return `
      :host {
        --rc-card: rgba(32,32,32,0.72);
        --rc-card2: rgba(32,32,32,0.55);
        --rc-border: rgba(255,255,255,0.08);
        --rc-muted: rgba(255,255,255,0.55);
        --rc-text: rgba(255,255,255,0.92);
        --rc-good: #43d17a;
        --rc-ok: #f4c542;
        --rc-bad: #ff5d5d;
        --rc-inactive: rgba(255,255,255,0.35);
        font-family: var(--primary-font-family, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif);
      }
      .rc-page { padding: 10px 12px 14px; color: var(--rc-text); }
      .rc-subheader { display:flex; align-items:center; gap: 10px; margin: 6px 0 12px; }
      .rc-back { width: 34px; height: 34px; border-radius: 10px; border: 1px solid var(--rc-border); background: rgba(255,255,255,0.04); color: var(--rc-text); font-size: 16px; cursor:pointer; }
      .rc-gear { width: 34px; height: 34px; border-radius: 10px; border: 1px solid var(--rc-border); background: rgba(255,255,255,0.04); color: var(--rc-muted); font-size: 16px; cursor:pointer; }
      .rc-gear:hover { filter: brightness(1.08); }
      .rc-subtitle { font-size: 18px; font-weight: 800; letter-spacing: 0.2px; }
      .rc-subspacer { flex:1; }

      .rc-grid { display:grid; grid-template-columns: 1fr 1fr; gap: 10px; }
      .span-2 { grid-column: span 2; }

      .rc-dtile {
        background: linear-gradient(180deg, var(--rc-card), var(--rc-card2));
        border: 1px solid var(--rc-border);
        border-radius: 14px;
        padding: 14px;
        box-shadow: 0 6px 18px rgba(0,0,0,0.35);
        min-height: 140px;
      }
      .rc-dtile-head { display:flex; justify-content:space-between; align-items:center; margin-bottom: 10px; }
      .rc-dtile-title { font-size: 13px; color: var(--rc-muted); font-weight: 700; }
      .rc-dtile-icon { color: var(--rc-muted); font-size: 14px; }

      .rc-row { display:flex; justify-content:space-between; align-items:center; padding: 6px 0; }
      .rc-label { color: var(--rc-muted); font-size: 13px; }
      .rc-val { font-weight: 700; font-size: 13px; }
      .rc-unit { margin-left: 4px; color: var(--rc-muted); font-weight: 600; }

      .rc-value { display:flex; align-items: baseline; gap: 6px; }
      .rc-value-num { font-weight: 900; letter-spacing: 0.2px; }
      .rc-value-xl { font-size: 42px; }
      .rc-value-lg { font-size: 30px; }
      .rc-value-md { font-size: 22px; }
      .rc-value-unit { font-size: 13px; color: var(--rc-muted); font-weight: 700; }

      .rc-badge { display:inline-flex; align-items:center; gap:8px; border-radius: 10px; padding: 6px 10px; border: 1px solid; }
      .rc-bdot { width: 8px; height: 8px; border-radius: 999px; display:inline-block; }
      .rc-btxt { font-weight: 800; font-size: 13px; }

      .rc-batt2 { width: 56px; height: 28px; }
      .rc-van { width: 140px; height: 64px; }
      .rc-vanwrap { display:inline-block; transition: transform 0.3s ease; }
      .rc-map { width: 100%; height: 100%; }
      .rc-mapbox { width: 100%; height: 220px; border-radius: 14px; overflow:hidden; border: 1px solid rgba(255,255,255,0.06); background: rgba(255,255,255,0.03); }
      .rc-btn { display:inline-flex; align-items:center; justify-content:center; width:100%; padding: 12px 12px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.10); background: rgba(255,255,255,0.05); color: var(--rc-text); font-weight: 800; cursor:pointer; }
      .rc-btn:hover { filter: brightness(1.05); }

      /* Setup banner */
      .rc-setup-banner {
        margin: 0 0 12px;
        padding: 12px 14px;
        border-radius: 14px;
        border: 1px solid rgba(255,255,255,0.10);
        background: linear-gradient(180deg, rgba(244,197,66,0.14), rgba(32,32,32,0.55));
        box-shadow: 0 10px 24px rgba(0,0,0,0.35);
      }
      .rc-setup-top { display:flex; align-items:flex-start; justify-content:space-between; gap: 10px; }
      .rc-setup-title { font-weight: 900; letter-spacing: 0.2px; }
      .rc-setup-sub { margin-top: 4px; color: var(--rc-muted); font-size: 13px; line-height: 1.35; }
      .rc-setup-actions { display:flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
      .rc-btn-small { width: auto; padding: 10px 12px; border-radius: 12px; }
      .rc-pill { display:inline-flex; align-items:center; padding: 4px 10px; border-radius: 999px; font-weight: 900; font-size: 12px; border: 1px solid rgba(255,255,255,0.10); }
      .rc-pill-demo { color: rgba(255,255,255,0.92); background: rgba(67,209,122,0.10); border-color: rgba(67,209,122,0.30); }

      /* Modal (Trip Wrapped options) */
      .rc-modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.55); display:flex; align-items:center; justify-content:center; padding: 14px; z-index: 9999; }
      .rc-modal { width: min(720px, calc(100vw - 28px)); max-height: min(80vh, 760px); overflow:auto; background: linear-gradient(180deg, rgba(26,26,26,0.96), rgba(18,18,18,0.96)); border: 1px solid rgba(255,255,255,0.10); border-radius: 16px; padding: 14px; box-shadow: 0 20px 60px rgba(0,0,0,0.55); }
      .rc-modal-head { display:flex; align-items:center; justify-content:space-between; gap: 10px; }
      .rc-input { width: 100%; padding: 10px 10px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.10); background: rgba(255,255,255,0.04); color: var(--rc-text); font-weight: 700; box-sizing: border-box; }
      .rc-input:focus { outline: none; border-color: rgba(67,209,122,0.55); }
      .rc-modal a { color: rgba(255,255,255,0.92); }

      @media (min-width: 1280px) {
        .rc-page { max-width: 1100px; margin: 0 auto; }
      }
    `;
  }

  // -----------------
  // Map helpers (Leaflet + breadcrumb trail)
  // -----------------
  async _ensureLeaflet() {
    try {
      if (window.L && window.L.map) return true;

      const cssId = 'rc-leaflet-css';
      const jsId = 'rc-leaflet-js';

      // IMPORTANT: Leaflet CSS must be available inside this component's shadow root
      // (global document styles don't pierce shadow DOM).
      if (!this.shadowRoot?.getElementById?.(cssId)) {
        const link = document.createElement('link');
        link.id = cssId;
        link.rel = 'stylesheet';
        link.href = '/local/roamcore/vendor/leaflet/leaflet.css?v=' + Date.now();
        const p = new Promise((resolve) => {
          link.onload = () => resolve(true);
          link.onerror = () => resolve(false);
        });
        (this.shadowRoot || document.head).appendChild(link);
        // Best-effort: wait a bit so tile positioning CSS is present before map init.
        try { await Promise.race([p, new Promise(r => setTimeout(r, 800))]); } catch (e) {}
      } else {
        // If CSS tag exists but stylesheet hasn't applied yet, give it a moment.
        try { await new Promise(r => setTimeout(r, 100)); } catch (e) {}
      }

      if (!document.getElementById(jsId)) {
        const src = '/local/roamcore/vendor/leaflet/leaflet.js';
        let lastErr = null;
        for (let i = 0; i < 4; i++) {
          try {
            await new Promise((resolve, reject) => {
              const s = document.createElement('script');
              s.id = jsId;
              s.src = src + (i ? `?v=${Date.now()}` : '');
              s.async = true;
              s.onload = resolve;
              s.onerror = reject;
              document.head.appendChild(s);
            });
            break;
          } catch (e) {
            lastErr = e;
            try { await new Promise(r => setTimeout(r, 400)); } catch (e2) {}
          }
        }
        if (lastErr && !(window.L && window.L.map)) {
          throw lastErr;
        }
      }

      return !!(window.L && window.L.map);
    } catch (e) {
      console.warn('leaflet load failed', e);
      return false;
    }
  }

  async _ensureMapLibre() {
    try {
      if (window.maplibregl && window.maplibregl.Map) return true;

      const jsId = 'rc-maplibre-js';
      const cssId = 'rc-maplibre-css';
      const jsUrl = '/local/roamcore/vendor/maplibre-gl/maplibre-gl.js';
      const cssUrl = '/local/roamcore/vendor/maplibre-gl/maplibre-gl.css';

      // IMPORTANT: MapLibre CSS must be available inside this component's shadow root.
      if (!this.shadowRoot?.getElementById?.(cssId)) {
        // Use <link> so the browser handles relative URLs inside CSS correctly.
        const link = document.createElement('link');
        link.id = cssId;
        link.rel = 'stylesheet';
        link.href = cssUrl + '?v=' + Date.now();
        const p = new Promise((resolve) => {
          link.onload = () => resolve(true);
          link.onerror = () => resolve(false);
        });
        (this.shadowRoot || document.head).appendChild(link);
        try { await Promise.race([p, new Promise(r => setTimeout(r, 800))]); } catch (e) {}
      } else {
        try { await new Promise(r => setTimeout(r, 100)); } catch (e) {}
      }

      if (!document.getElementById(jsId)) {
        await new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.id = jsId;
          s.src = jsUrl;
          s.async = true;
          s.onload = resolve;
          s.onerror = reject;
          document.head.appendChild(s);
        });
      }

      return !!(window.maplibregl && window.maplibregl.Map);
    } catch (e) {
      console.warn('maplibre load failed', e);
      return false;
    }
  }

  async _loadJson(url) {
    const res = await fetch(url, { cache: 'no-cache' });
    if (!res.ok) throw new Error(`fetch failed ${res.status} for ${url}`);
    return await res.json();
  }

  _loadSavedMapView() {
    try {
      const raw = localStorage.getItem('rc_map_view_v1');
      if (!raw) return null;
      const o = JSON.parse(raw);
      const lat = Number(o?.lat);
      const lon = Number(o?.lon);
      const zoom = Number(o?.zoom);
      if (!Number.isFinite(lat) || !Number.isFinite(lon) || !Number.isFinite(zoom)) return null;
      return { lat, lon, zoom };
    } catch (e) {
      return null;
    }
  }

  _loadSavedMapViewMapLibre() {
    try {
      const raw = localStorage.getItem('rc_map_view_maplibre_v1');
      if (!raw) return null;
      const o = JSON.parse(raw);
      const lat = Number(o?.lat);
      const lon = Number(o?.lon);
      const zoom = Number(o?.zoom);
      if (!Number.isFinite(lat) || !Number.isFinite(lon) || !Number.isFinite(zoom)) return null;
      return { lat, lon, zoom };
    } catch (e) {
      return null;
    }
  }

  _saveMapViewMapLibre(map) {
    try {
      if (!map) return;
      const c = map.getCenter?.();
      const z = map.getZoom?.();
      if (!c || !Number.isFinite(c.lat) || !Number.isFinite(c.lng) || !Number.isFinite(z)) return;
      localStorage.setItem('rc_map_view_maplibre_v1', JSON.stringify({ lat: c.lat, lon: c.lng, zoom: z }));
    } catch (e) {}
  }

  _saveMapView(map) {
    try {
      if (!map) return;
      const c = map.getCenter?.();
      const z = map.getZoom?.();
      if (!c || !Number.isFinite(c.lat) || !Number.isFinite(c.lng) || !Number.isFinite(z)) return;
      localStorage.setItem('rc_map_view_v1', JSON.stringify({ lat: c.lat, lon: c.lng, zoom: z }));
    } catch (e) {}
  }

  async _getTraccarRoutePositions({ deviceId = null, hours = 6 } = {}) {
    try {
      if (!this._hass) return [];

      let did = deviceId;
      if (!did) {
        // Prefer dedicated route device (allows demo device without affecting other features).
        const routeDid = Number(this._getState('input_number.rc_map_route_device_id'));
        if (Number.isFinite(routeDid) && routeDid > 0) did = routeDid;
      }
      if (!did) {
        const configured = Number(this._getState('input_number.rc_traccar_device_id'));
        if (Number.isFinite(configured) && configured > 0) did = configured;
      }
      if (!did) {
        const devices = await this._hass.callApi('get', 'roamcore/traccar_api/devices').catch(() => []);
        did = Array.isArray(devices) && devices[0]?.id ? devices[0].id : null;
      }
      if (!did) return [];

      const to = new Date();
      const from = new Date(to.getTime() - (hours * 3600_000));
      const q = new URLSearchParams({
        deviceId: String(did),
        from: from.toISOString(),
        to: to.toISOString(),
      });
      const positions = await this._hass
        .callApi('get', `roamcore/traccar_api/reports/route?${q.toString()}`)
        .catch(() => []);
      if (!Array.isArray(positions)) return [];
      return positions;
    } catch (e) {
      return [];
    }
  }

  _positionsToGeojsonLine(positions) {
    try {
      // Convert to [lon,lat] and aggressively de-noise/decimate so rendering stays stable on mobile.
      // Traccar can return a lot of points (30s cadence), and MapLibre line triangulation can glitch.
      const sorted = [...(positions || [])].sort((a, b) => {
        const ta = new Date(a?.fixTime || a?.deviceTime || a?.serverTime || 0).getTime();
        const tb = new Date(b?.fixTime || b?.deviceTime || b?.serverTime || 0).getTime();
        return ta - tb;
      });

      const raw = sorted
        .map(p => {
          const lat = Number(p?.latitude);
          const lon = Number(p?.longitude);
          return (Number.isFinite(lat) && Number.isFinite(lon)) ? [lon, lat] : null;
        })
        .filter(Boolean);

      if (raw.length < 2) return null;

      const coords = [];
      let last = null;
      const minMeters = 25; // keep points only if moved at least this far
      const toRad = (x) => (x * Math.PI) / 180;
      const distM = (a, b) => {
        // Haversine
        const R = 6371000;
        const dLat = toRad(b[1] - a[1]);
        const dLon = toRad(b[0] - a[0]);
        const lat1 = toRad(a[1]);
        const lat2 = toRad(b[1]);
        const s = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
        return 2 * R * Math.asin(Math.sqrt(s));
      };

      for (const c of raw) {
        if (!last) {
          coords.push(c);
          last = c;
          continue;
        }
        if (distM(last, c) >= minMeters) {
          coords.push(c);
          last = c;
        }
      }

      // Always include final point.
      const final = raw[raw.length - 1];
      if (coords.length && (coords[coords.length - 1][0] != final[0] || coords[coords.length - 1][1] != final[1])) {
        coords.push(final);
      }
      if (coords.length < 2) return null;

      // Split into segments if there are big jumps (prevents huge "wedge" joins rendering as triangles).
      const jumpMeters = 2500;
      const segments = [];
      let seg = [coords[0]];
      for (let i = 1; i < coords.length; i++) {
        const a = coords[i - 1];
        const b = coords[i];
        if (distM(a, b) > jumpMeters) {
          if (seg.length >= 2) segments.push(seg);
          seg = [b];
        } else {
          seg.push(b);
        }
      }
      if (seg.length >= 2) segments.push(seg);
      if (!segments.length) return null;

      const geom = segments.length === 1
        ? { type: 'LineString', coordinates: segments[0] }
        : { type: 'MultiLineString', coordinates: segments };

      return {
        type: 'Feature',
        properties: { pointCount: coords.length, segmentCount: segments.length },
        geometry: geom,
      };
    } catch (e) {
      return null;
    }
  }

  _lineToBreadcrumbPoints(lineFeature, { everyN = 12 } = {}) {
    try {
      const geom = lineFeature?.geometry;
      if (!geom) return null;
      let coords = null;
      if (geom.type === 'LineString') coords = geom.coordinates;
      else if (geom.type === 'MultiLineString') coords = (geom.coordinates || []).flat();
      if (!Array.isArray(coords) || coords.length < 2) return null;
      const features = [];
      for (let i = 0; i < coords.length; i += Math.max(2, everyN)) {
        const c = coords[i];
        if (!Array.isArray(c) || c.length < 2) continue;
        features.push({
          type: 'Feature',
          properties: { i },
          geometry: { type: 'Point', coordinates: c },
        });
      }
      // Always add end point.
      const last = coords[coords.length - 1];
      features.push({ type: 'Feature', properties: { i: coords.length - 1, end: true }, geometry: { type: 'Point', coordinates: last } });
      return { type: 'FeatureCollection', features };
    } catch (e) {
      return null;
    }
  }

  _lineToEndpoints(lineFeature) {
    try {
      const geom = lineFeature?.geometry;
      if (!geom) return null;
      const getFirstLast = (coords) => ({ first: coords?.[0], last: coords?.[coords.length - 1] });
      let first = null;
      let last = null;
      if (geom.type === 'LineString') {
        ({ first, last } = getFirstLast(geom.coordinates));
      } else if (geom.type === 'MultiLineString') {
        const segs = geom.coordinates || [];
        if (segs.length) {
          first = segs[0]?.[0];
          const tail = segs[segs.length - 1];
          last = tail?.[tail.length - 1];
        }
      }
      if (!first || !last) return null;
      return {
        type: 'FeatureCollection',
        features: [
          { type: 'Feature', properties: { kind: 'start' }, geometry: { type: 'Point', coordinates: first } },
          { type: 'Feature', properties: { kind: 'end' }, geometry: { type: 'Point', coordinates: last } },
        ],
      };
    } catch (e) {
      return null;
    }
  }

  _pickTrackerEntity() {
    const configured = this._getState('input_text.rc_location_tracker_entity');
    if (configured && configured !== 'unknown' && configured !== 'unavailable' && String(configured).trim()) {
      return String(configured).trim();
    }
    try {
      const st = this._hass?.states || {};
      for (const id of Object.keys(st)) {
        if (!id.startsWith('device_tracker.')) continue;
        const a = st[id]?.attributes || {};
        if (a.latitude != null && a.longitude != null) return id;
      }
    } catch (e) {}
    return null;
  }

  async _loadTrail(trackerId, hours = 6) {
    if (!this._hass || !trackerId) return [];
    try {
      const start = new Date(Date.now() - hours * 3600_000).toISOString();
      const url = `history/period/${encodeURIComponent(start)}?filter_entity_id=${encodeURIComponent(trackerId)}`;
      const rows = await this._hass.callApi('GET', url);
      const list = Array.isArray(rows) && rows.length ? rows[0] : [];
      const pts = [];
      for (const s of list) {
        const a = (s && s.attributes) || {};
        const lat = Number(a.latitude);
        const lon = Number(a.longitude);
        if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
        pts.push([lat, lon]);
      }
      const out = [];
      for (const p of pts) {
        const prev = out[out.length - 1];
        if (prev && Math.abs(prev[0] - p[0]) < 1e-6 && Math.abs(prev[1] - p[1]) < 1e-6) continue;
        out.push(p);
      }
      return out;
    } catch (e) {
      console.warn('trail load failed', e);
      return [];
    }
  }

  async _mountLeafletMap(el, { lat, lon, trackerId } = {}) {
    try {
      if (!el) return;
      const ok = await this._ensureLeaflet();
      if (!ok) {
        el.innerHTML = '<div class="rc-label">Map failed to load (Leaflet missing).</div>';
        return;
      }
      if (el._rcMap) return;

      // If we don't have an HA GPS fix yet, try Traccar last known position
      // so the map still renders during early bring-up / mock-data testing.
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        try {
          const fix = await this._getTraccarLastFix();
          if (fix && Number.isFinite(fix.lat) && Number.isFinite(fix.lon)) {
            lat = fix.lat;
            lon = fix.lon;
          }
        } catch (e) {}
      }
      // Deterministic fallback: if we still don't have a fix, center on a
      // reasonable default (UK-ish) so the map never goes blank.
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        lat = 54.5;
        lon = -3.0;
      }

      const L = window.L;
      // Zoom lock: avoid over-zooming beyond available offline tiles.
      // If online tiles are configured, we can allow higher zoom; otherwise clamp.
      const offlineMaxZ = this._offlineMaxZoom();
      const onlineUrl = this._onlineTileUrl();
      const maxZ = onlineUrl ? 19 : offlineMaxZ;
      const m = L.map(el, { zoomControl: false, attributionControl: false, maxZoom: maxZ });
      el._rcMap = m;

      // If the user pans/zooms, never auto-recenter again.
      try {
        el._rcUserMoved = false;
        const markMoved = () => { try { el._rcUserMoved = true; } catch (e) {} };
        m.on('movestart', markMoved);
        m.on('zoomstart', markMoved);
      } catch (e) {}

      // If we don't have a live HA tracker fix, poll Traccar periodically and
      // update the view + marker. This makes live GPS work even when the HA
      // device_tracker isn't configured yet.
      try {
        if (!el._rcTraccarPoll) {
          el._rcTraccarPoll = setInterval(async () => {
            try {
              const fix = await this._getTraccarLastFix();
              if (!fix || !Number.isFinite(fix.lat) || !Number.isFinite(fix.lon)) return;
              const ll = [Number(fix.lat), Number(fix.lon)];
              // Update marker.
              try {
                if (el._rcTraccarMarker) {
                  el._rcTraccarMarker.setLatLng(ll);
                } else {
                  el._rcTraccarMarker = L.circleMarker(ll, {
                    radius: 6,
                    color: '#0ea5e9',
                    weight: 2,
                    fillColor: '#0ea5e9',
                    fillOpacity: 0.7,
                  }).addTo(m);
                }
              } catch (e) {}
              // If we were on fallback center, gently follow once.
              try {
                const saved = this._loadSavedMapView();
                if (!el._rcTraccarDidCenter && !saved && !el._rcUserMoved) {
                  el._rcTraccarDidCenter = true;
                  m.setView(ll, Math.min(m.getZoom() || 8, 10), { animate: false });
                }
              } catch (e) {}
            } catch (e) {}
          }, 10_000);
        }
      } catch (e) {}

      // Hybrid tile setup: local offline tiles + online fallback for higher zooms.
      // Local tiles serve z0–offlineMaxZoom; online tiles fill in above that (if configured).
      const localUrl = this._tileUrl();

      // Base layer: local offline tiles (always available, even without internet)
      const localLayer = L.tileLayer(localUrl, {
        maxZoom: offlineMaxZ,
        crossOrigin: true,
        updateWhenIdle: true,
        keepBuffer: 4,
      });
      localLayer.addTo(m);

      // Hard clamp in case mobile pinch-zoom overshoots.
      try {
        m.on('zoomend', () => {
          try {
            const z = m.getZoom();
            if (Number.isFinite(z) && z > maxZ) m.setZoom(maxZ);
          } catch (e) {}
        });
      } catch (e) {}

      // If the local tile endpoint is missing/misconfigured, Leaflet will quietly render grey.
      // Detect repeated tile errors and fall back to online tiles (if configured) to avoid a
      // permanently blank map during bring-up.
      let localTileErrors = 0;
      let localTileFirstErrorAt = 0;
      let onlineFallbackLayer = null;
      const maybeEnableOnlineFallback = () => {
        try {
          if (!onlineUrl) return;
          if (onlineFallbackLayer) return;
          // If we see many errors quickly, assume local tiles are unavailable.
          const now = Date.now();
          if (localTileErrors < 6) return;
          if (localTileFirstErrorAt && (now - localTileFirstErrorAt) > 10_000) return;
          onlineFallbackLayer = L.tileLayer(onlineUrl, {
            minZoom: 0,
            maxZoom: 19,
            crossOrigin: true,
            updateWhenIdle: true,
            keepBuffer: 2,
          });
          onlineFallbackLayer.addTo(m);
          try { localLayer.setOpacity(0); } catch (e) {}
        } catch (e) {}
      };
      try {
        localLayer.on('tileerror', () => {
          localTileErrors++;
          if (!localTileFirstErrorAt) localTileFirstErrorAt = Date.now();
          maybeEnableOnlineFallback();
        });
      } catch (e) {}

      // Detail layer: online tiles for higher zoom levels (only loads when zoomed past offline coverage)
      if (onlineUrl) {
        const onlineLayer = L.tileLayer(onlineUrl, {
          minZoom: offlineMaxZ + 1,
          maxZoom: 19,
          crossOrigin: true,
          updateWhenIdle: true,
          keepBuffer: 2,
        });
        onlineLayer.addTo(m);
      }

      const trail = await this._loadTrail(trackerId, 6);
      const pts = (trail && trail.length ? trail : [[lat, lon]]);

      const saved = this._loadSavedMapView();
      if (saved) {
        m.setView([saved.lat, saved.lon], saved.zoom);
      } else if (pts.length >= 2) {
        const line = L.polyline(pts, { color: '#22c55e', weight: 4, opacity: 0.85 });
        line.addTo(m);
        m.fitBounds(line.getBounds(), { padding: [18, 18] });
      } else {
        m.setView([lat, lon], 14);
      }

      L.circleMarker([lat, lon], { radius: 8, color: '#0ea5e9', weight: 3, fillColor: '#0ea5e9', fillOpacity: 0.9 }).addTo(m);
      L.control.zoom({ position: 'bottomright' }).addTo(m);

      // Leaflet often needs an explicit resize once the container is visible / laid out.
      try {
        setTimeout(() => { try { m.invalidateSize(true); } catch (e) {} }, 50);
        setTimeout(() => { try { m.invalidateSize(true); } catch (e) {} }, 300);
        setTimeout(() => { try { m.invalidateSize(true); } catch (e) {} }, 1200);
      } catch (e) {}

      // Persist view so refresh doesn't snap back every time.
      try {
        m.on('moveend', () => this._saveMapView(m));
        m.on('zoomend', () => this._saveMapView(m));
      } catch (e) {}

      return m;
    } catch (e) {
      console.warn('leaflet mount failed', e);
      try { el.innerHTML = '<div class="rc-label">Map failed to render.</div>'; } catch (e2) {}
    }
  }

  async _mountMapLibreMap(el, { lat, lon } = {}) {
    try {
      if (!el) return;
      const ok = await this._ensureMapLibre();
      if (!ok) {
        el.innerHTML = '<div class="rc-label">Map failed to load (MapLibre missing).</div>';
        return;
      }
      if (el._rcMapLibre) {
        // Idempotent: don't recreate the map on HA re-renders.
        try { el._rcMapLibre.resize(); } catch (e) {}
        return el._rcMapLibre;
      }

      // If we don't have a GPS fix yet, fall back to Traccar last fix.
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        try {
          const fix = await this._getTraccarLastFix();
          if (fix && Number.isFinite(fix.lat) && Number.isFinite(fix.lon)) {
            lat = fix.lat;
            lon = fix.lon;
          }
        } catch (e) {}
      }
      // Deterministic fallback: if we still don't have a fix, center on a
      // reasonable default so the map never goes blank.
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        lat = 54.5;
        lon = -3.0;
      }

      const styleUrl = this._mapStyleUrl();
      if (!styleUrl) {
        el.innerHTML = '<div class="rc-label">No vector map style URL configured.</div>';
        return;
      }

      // Beta: online-only map.

      // MapLibre wants a dedicated container node.
      el.innerHTML = '';
      const container = document.createElement('div');
      container.style.width = '100%';
      container.style.height = '100%';
      el.appendChild(container);

      const saved = this._loadSavedMapViewMapLibre();
      const centerLon = saved ? Number(saved.lon) : Number(lon);
      const centerLat = saved ? Number(saved.lat) : Number(lat);
      const zoom = saved ? Number(saved.zoom) : 10;

      const origin = (() => {
        try { return window.location.origin; } catch (e) { return ''; }
      })();

      const minimalRasterStyle = () => ({
        version: 8,
        glyphs: `${origin}/local/roamcore/fonts/{fontstack}/{range}.pbf`,
        sprite: `${origin}/local/roamcore/sprites/rc-sprite`,
        sources: {
          rc_raster: {
            type: 'raster',
            tiles: ['/rc-tiles/{z}/{x}/{y}.png'],
            tileSize: 256,
            maxzoom: 18,
          },
        },
        layers: [
          { id: 'background', type: 'background', paint: { 'background-color': '#0b1220' } },
          { id: 'rc_raster', type: 'raster', source: 'rc_raster', paint: { 'raster-opacity': 1.0 } },
        ],
      });

      // Allow using a local JSON style and patching in the current origin.
      let style = styleUrl;
      try {
        if (typeof styleUrl === 'string' && styleUrl.startsWith('/local/roamcore/styles/') && styleUrl.endsWith('.json')) {
          const obj = await this._loadJson(styleUrl);
          const replaceOrigin = (v) => (typeof v === 'string' ? v.replaceAll('__ORIGIN__', origin) : v);
          if (obj && obj.sources) {
            for (const k of Object.keys(obj.sources)) {
              if (obj.sources[k] && obj.sources[k].url) obj.sources[k].url = replaceOrigin(obj.sources[k].url);
              if (obj.sources[k] && obj.sources[k].tiles) obj.sources[k].tiles = (obj.sources[k].tiles || []).map(replaceOrigin);
            }
          }
          if (obj && obj.sprite) obj.sprite = replaceOrigin(obj.sprite);
          if (obj && obj.glyphs) obj.glyphs = replaceOrigin(obj.glyphs);
          style = obj;
        }
      } catch (e) {
        console.warn('failed to load/patch style json; falling back to raster-only style', e);
        style = minimalRasterStyle();
      }

      // If a remote style URL is configured and fails later, MapLibre will emit an error.
      // RoamCore prefers a consistent basemap. Fall back to Leaflet only if MapLibre fails.

      const m = new maplibregl.Map({
        container,
        style,
        center: [centerLon, centerLat],
        zoom,
        // Keep zoom sane for mobile.
        maxZoom: this._maplibreMaxZoom(styleUrl, centerLat, centerLon),
        attributionControl: false,
      });
      m.addControl(new maplibregl.NavigationControl({ showCompass: true, showZoom: true }), 'top-right');
      el._rcMapLibre = m;

      // If MapLibre emits repeated tile errors (often due to CORS/range issues),
      // fall back to Leaflet raster so the user always has a usable map.
      try {
        let errCount = 0;
        m.on('error', async (ev) => {
          try {
            errCount += 1;
            if (errCount < 3) return;
            if (el._rcMapLibreFailed) return;
            el._rcMapLibreFailed = true;
            console.warn('maplibre error; falling back to Leaflet', ev?.error || ev);
            try { m.remove?.(); } catch (e) {}
            try { delete el._rcMapLibre; } catch (e) { el._rcMapLibre = null; }
            await this._mountLeafletMap(el, { lat, lon, trackerId: this._pickTrackerEntity() });
          } catch (e) {}
        });
      } catch (e) {}

      // If the user pans/zooms, stop auto-recentering.
      try {
        el._rcUserMoved = false;
        const markMoved = () => { try { el._rcUserMoved = true; } catch (e) {} };
        m.on('dragstart', markMoved);
        m.on('zoomstart', markMoved);
      } catch (e) {}

      // If we don't have live HA GPS yet, poll Traccar periodically and update the marker.
      try {
        if (!el._rcTraccarPoll) {
          el._rcTraccarPoll = setInterval(async () => {
            try {
              const fix = await this._getTraccarLastFix();
              if (!fix || !Number.isFinite(fix.lat) || !Number.isFinite(fix.lon)) return;
              const lngLat = [Number(fix.lon), Number(fix.lat)];
              try {
                if (!el._rcMapLibreMarker) {
                  el._rcMapLibreMarker = new maplibregl.Marker({ color: '#0ea5e9' })
                    .setLngLat(lngLat)
                    .addTo(m);
                } else {
                  el._rcMapLibreMarker.setLngLat(lngLat);
                }
              } catch (e) {}
              // Only auto-center once during initial bring-up, and only if the
              // user hasn't moved the map AND we didn't restore a saved view.
              try {
                if (!el._rcTraccarDidCenter && !saved && !el._rcUserMoved) {
                  el._rcTraccarDidCenter = true;
                  m.setCenter(lngLat);
                }
              } catch (e) {}
            } catch (e) {}
          }, 10_000);
        }
      } catch (e) {}

      // Intentionally NO always-on raster fallback layer.
      // If MapLibre fails to load tiles, fall back to Leaflet when needed.

      // Ensure marker exists and is updated on every render tick.
      const ensureMarker = () => {
        try {
          if (!Number.isFinite(lon) || !Number.isFinite(lat)) return;
          if (!el._rcMapLibreMarker) {
            el._rcMapLibreMarker = new maplibregl.Marker({ color: '#0ea5e9' })
              .setLngLat([Number(lon), Number(lat)])
              .addTo(m);
          } else {
            el._rcMapLibreMarker.setLngLat([Number(lon), Number(lat)]);
          }
        } catch (e) {}
      };

      // Route polyline: production path is Traccar reports/route. Fall back to mock GeoJSON.
      try {
        const mockUrl = '/local/roamcore/mock/track.geojson';

        const upsertRoute = async () => {
          try {
            // 1) Source-of-truth: Traccar route
            const positions = await this._getTraccarRoutePositions({ hours: 6 });
            let gj = this._positionsToGeojsonLine(positions);

            // 2) Fallback: mock demo route
            if (!gj) {
              const r = await fetch(mockUrl, { cache: 'no-cache' }).catch(() => null);
              if (r && r.ok) {
                const j = await r.json().catch(() => null);
                if (j && j.geometry) gj = j;
              }
            }
            if (!gj) return;

            const crumbs = this._lineToBreadcrumbPoints(gj, { everyN: 10 });
            const ends = this._lineToEndpoints(gj);

            if (!m.getSource('rc_route')) {
              m.addSource('rc_route', { type: 'geojson', data: gj });

              if (crumbs) m.addSource('rc_route_points', { type: 'geojson', data: crumbs });
              if (ends) m.addSource('rc_route_ends', { type: 'geojson', data: ends });

              // Google-ish route styling: casing + inner stroke.
              m.addLayer({
                id: 'rc_route_casing',
                type: 'line',
                source: 'rc_route',
                layout: { 'line-join': 'round', 'line-cap': 'round' },
                paint: {
                  'line-color': 'rgba(0,0,0,0.35)',
                  // Keep widths modest to avoid GPU triangulation artifacts.
                  'line-width': ['interpolate', ['linear'], ['zoom'], 4, 3, 8, 5, 12, 7, 16, 10],
                  'line-opacity': 0.9,
                },
              });
              m.addLayer({
                id: 'rc_route_line',
                type: 'line',
                source: 'rc_route',
                layout: { 'line-join': 'round', 'line-cap': 'round' },
                paint: {
                  'line-color': '#1a73e8',
                  'line-width': ['interpolate', ['linear'], ['zoom'], 4, 2, 8, 3.5, 12, 5.5, 16, 8],
                  'line-opacity': 0.95,
                },
              });

              // Breadcrumb dots along the route.
              if (crumbs) {
                m.addLayer({
                  id: 'rc_route_dots_outline',
                  type: 'circle',
                  source: 'rc_route_points',
                  paint: {
                    'circle-radius': ['interpolate', ['linear'], ['zoom'], 4, 2, 8, 3, 12, 4, 16, 5],
                    'circle-color': '#1a73e8',
                    'circle-opacity': 0.95,
                  },
                });
                m.addLayer({
                  id: 'rc_route_dots',
                  type: 'circle',
                  source: 'rc_route_points',
                  paint: {
                    'circle-radius': ['interpolate', ['linear'], ['zoom'], 4, 1.2, 8, 2, 12, 2.6, 16, 3.2],
                    'circle-color': '#ffffff',
                    'circle-opacity': 0.9,
                  },
                });
              }

              // Start/end markers.
              if (ends) {
                m.addLayer({
                  id: 'rc_route_ends',
                  type: 'circle',
                  source: 'rc_route_ends',
                  paint: {
                    'circle-radius': ['interpolate', ['linear'], ['zoom'], 4, 4, 8, 6, 12, 8, 16, 10],
                    'circle-color': [
                      'match',
                      ['get', 'kind'],
                      'start', '#34a853',
                      'end', '#ea4335',
                      '#1a73e8',
                    ],
                    'circle-stroke-color': '#ffffff',
                    'circle-stroke-width': 2,
                    'circle-opacity': 0.95,
                  },
                });
              }

              // Auto-fit to the route once (first-run only).
              // IMPORTANT: never override a user-restored view.
              // - If we loaded a saved view from localStorage, keep it.
              // - If the user already panned/zoomed, keep it.
              // - Persist the "did fit" flag on the *element*, not the page instance,
              //   so HA re-renders don't cause repeated snapping.
              try {
                const alreadyFit = !!el._rcRouteFitDone;
                const userMoved = !!el._rcUserMoved;
                const hasSaved = !!saved;
                if (!alreadyFit && !userMoved && !hasSaved) {
                  const bounds = new maplibregl.LngLatBounds();
                  const addCoord = (c) => { if (c && c.length >= 2) bounds.extend([c[0], c[1]]); };
                  if (gj.geometry.type === 'LineString') {
                    for (const c of gj.geometry.coordinates) addCoord(c);
                  } else if (gj.geometry.type === 'MultiLineString') {
                    for (const seg of gj.geometry.coordinates) for (const c of seg) addCoord(c);
                  }
                  if (!bounds.isEmpty()) {
                    m.fitBounds(bounds, { padding: 40, duration: 0, maxZoom: 8 });
                    el._rcRouteFitDone = true;
                  }
                }
              } catch (e) {}
            } else {
              m.getSource('rc_route').setData(gj);
              try {
                if (crumbs && m.getSource('rc_route_points')) m.getSource('rc_route_points').setData(crumbs);
              } catch (e) {}
              try {
                if (ends && m.getSource('rc_route_ends')) m.getSource('rc_route_ends').setData(ends);
              } catch (e) {}
            }
          } catch (e) {}
        };

        m.on('load', async () => {
          try { ensureMarker(); } catch (e) {}
          await upsertRoute();
          // Refresh once after initial render; navigation sometimes races style load.
          try { setTimeout(() => { upsertRoute(); }, 1200); } catch (e) {}
        });
      } catch (e) {}

      // Keep marker in sync even if the map was mounted before we had a fix.
      try {
        ensureMarker();
        m.on('styledata', ensureMarker);
      } catch (e) {}

      // Persist view so refresh doesn't snap back.
      try {
        m.on('moveend', () => this._saveMapViewMapLibre(m));
        m.on('zoomend', () => this._saveMapViewMapLibre(m));
      } catch (e) {}

      // Resize after layout.
      try {
        setTimeout(() => { try { m.resize(); } catch (e) {} }, 50);
        setTimeout(() => { try { m.resize(); } catch (e) {} }, 300);
      } catch (e) {}

      return m;
    } catch (e) {
      console.warn('maplibre mount failed', e);
      try { el.innerHTML = '<div class="rc-label">Map failed to render.</div>'; } catch (e2) {}
    }
  }

  async _getTraccarLastFix() {
    try {
      if (!this._hass) return null;

      // Pick the first device and follow its positionId.
      const devs = await this._hass.callApi('GET', 'roamcore/traccar_api/devices').catch(() => []);
      if (!Array.isArray(devs) || devs.length === 0) return null;
      const d = devs[0] || {};
      const posId = d.positionId;
      if (!posId) return null;

      const positions = await this._hass.callApi('GET', `roamcore/traccar_api/positions?id=${encodeURIComponent(posId)}`).catch(() => []);
      const p = Array.isArray(positions) && positions.length ? positions[0] : null;
      if (!p) return null;

      const lat = Number(p.latitude);
      const lon = Number(p.longitude);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
      return { lat, lon, fixTime: p.fixTime || null };
    } catch (e) {
      return null;
    }
  }
}

class RoamcorePowerPage extends RoamcoreBasePage {
  _render() {
    if (!this._root || !this._hass) return;

    // Contract entities currently available (MVP)
    const soc = this._num('sensor.rc_power_battery_soc', null);
    const battV = this._num('sensor.rc_power_battery_voltage', null);
    const battA = this._num('sensor.rc_power_battery_current', null);
    const battT = this._num('sensor.rc_power_battery_temperature', null) ?? this._num('sensor.rc_power_battery_temperature_2', null);
    const battCap = this._num('sensor.rc_power_battery_capacity', null);
    const battCycles = this._num('sensor.rc_power_battery_cycle_count', null);
    const battHealth = this._num('sensor.rc_power_battery_health', null);

    const solarW = this._num('sensor.rc_power_solar_power', null);
    const solarToday = this._num('sensor.rc_power_solar_energy_today', null);
    const solarTotal = this._num('sensor.rc_power_solar_energy_total', null);
    const solarPV = this._num('sensor.rc_power_solar_panel_voltage', null);
    const solarPA = this._num('sensor.rc_power_solar_panel_current', null);
    const solarEff = this._num('sensor.rc_power_solar_efficiency', null);

    const loadW = this._num('sensor.rc_power_load_power', null);
    const loadFridge = this._num('sensor.rc_power_load_fridge', null);
    const loadLights = this._num('sensor.rc_power_load_lights', null);
    const loadHeater = this._num('sensor.rc_power_load_heater', null);
    const loadPump = this._num('sensor.rc_power_load_water_pump', null);
    const loadOther = this._num('sensor.rc_power_load_other', null);

    const inv = this._getState('sensor.rc_power_inverter_status');
    const invOutW = this._num('sensor.rc_power_inverter_output_power', null);
    const invOutV = this._num('sensor.rc_power_inverter_output_voltage', null);
    const invHz = this._num('sensor.rc_power_inverter_frequency', null);
    const invTemp = this._num('sensor.rc_power_inverter_temperature', null);

    const shore = this._getState('binary_sensor.rc_power_shore_connected');
    const shoreV = this._num('sensor.rc_power_shore_voltage', null);
    const shoreA = this._num('sensor.rc_power_shore_current', null);
    const shoreW = this._num('sensor.rc_power_shore_power', null);

    const altV = this._num('sensor.rc_power_alternator_voltage', null);
    const altA = this._num('sensor.rc_power_alternator_current', null);
    const altW = this._num('sensor.rc_power_alternator_power', null);

    const status = rcPowerStatusFromSoc(soc);
    const c = rcStatusToColor(status);

    const batteryTop = `
      <div style="display:flex; gap:14px; align-items:center; margin-bottom: 12px;">
        ${this._batterySvg(soc ?? 0, c)}
        <div class="rc-value">
          <div class="rc-value-num rc-value-xl" style="color:${c}">${soc == null ? '—' : Math.round(soc)}</div>
          <div class="rc-value-unit">%</div>
        </div>
        ${this._badge(status === 'good' ? 'Healthy' : status === 'ok' ? 'OK' : 'Low', status)}
      </div>
    `;

    const batteryRows = `
      ${this._row('Voltage', battV == null ? '—' : round1(battV), 'V', '', 'sensor.rc_power_battery_voltage')}
      ${this._row('Current', battA == null ? '—' : round1(battA), 'A', '', 'sensor.rc_power_battery_current')}
      ${this._row('Temperature', battT == null ? '—' : round1(battT), '°C', '', battT == null ? '' : 'sensor.rc_power_battery_temperature')}
      ${this._row('Capacity', battCap == null ? '—' : round1(battCap), 'Ah', '', 'sensor.rc_power_battery_capacity')}
      ${this._row('Cycles', battCycles == null ? '—' : Math.round(battCycles), '', '', 'sensor.rc_power_battery_cycle_count')}
      ${this._row('Health', battHealth == null ? '—' : Math.round(battHealth), '%', '', 'sensor.rc_power_battery_health')}
    `;

    const solar = `
      <div class="rc-value" style="margin-bottom:10px;">
        <div class="rc-value-num rc-value-lg" data-more="sensor.rc_power_solar_power" style="color:${rcStatusToColor('good')}">${solarW == null ? '—' : Math.round(solarW)}</div>
        <div class="rc-value-unit">W</div>
      </div>
      ${this._row('Today', solarToday == null ? '—' : round1(solarToday), 'kWh', '', 'sensor.rc_power_solar_energy_today')}
      ${this._row('Total', solarTotal == null ? '—' : round1(solarTotal), 'kWh', '', 'sensor.rc_power_solar_energy_total')}
      ${this._row('Panel V', solarPV == null ? '—' : round1(solarPV), 'V', '', 'sensor.rc_power_solar_panel_voltage')}
      ${this._row('Panel A', solarPA == null ? '—' : round1(solarPA), 'A', '', 'sensor.rc_power_solar_panel_current')}
      ${this._row('Efficiency', solarEff == null ? '—' : Math.round(solarEff), '%', '', 'sensor.rc_power_solar_efficiency')}
    `;

    const loads = `
      <div class="rc-value" style="margin-bottom:10px;">
        <div class="rc-value-num rc-value-lg" data-more="sensor.rc_power_load_power">${loadW == null ? '—' : Math.round(loadW)}</div>
        <div class="rc-value-unit">W</div>
      </div>
      ${this._row('Fridge', loadFridge == null ? '—' : Math.round(loadFridge), 'W', '', 'sensor.rc_power_load_fridge')}
      ${this._row('Lights', loadLights == null ? '—' : Math.round(loadLights), 'W', '', 'sensor.rc_power_load_lights')}
      ${this._row('Heater', loadHeater == null ? '—' : Math.round(loadHeater), 'W', (loadHeater == null || loadHeater == 0) ? rcStatusToColor('inactive') : '', 'sensor.rc_power_load_heater')}
      ${this._row('Water Pump', loadPump == null ? '—' : Math.round(loadPump), 'W', '', 'sensor.rc_power_load_water_pump')}
      ${this._row('Other', loadOther == null ? '—' : Math.round(loadOther), 'W', '', 'sensor.rc_power_load_other')}
    `;

    const inverter = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 10px;">
        <div data-more="sensor.rc_power_inverter_status">${this._badge((inv && inv !== 'unknown' && inv !== 'unavailable') ? rcCap(inv) : '—', (inv && inv !== 'off') ? 'good' : 'inactive')}</div>
        <div class="rc-label" style="text-transform:uppercase; font-weight:700;">eco</div>
      </div>
      ${this._row('Output', invOutW == null ? '—' : Math.round(invOutW), 'W', '', 'sensor.rc_power_inverter_output_power')}
      ${this._row('Voltage', invOutV == null ? '—' : round1(invOutV), 'V', '', 'sensor.rc_power_inverter_output_voltage')}
      ${this._row('Frequency', invHz == null ? '—' : round1(invHz), 'Hz', '', 'sensor.rc_power_inverter_frequency')}
      ${this._row('Temperature', invTemp == null ? '—' : round1(invTemp), '°C', '', 'sensor.rc_power_inverter_temperature')}
    `;

    const shoreTile = `
      <div style="margin-bottom: 10px;">
        <div data-more="binary_sensor.rc_power_shore_connected">${this._badge(shore === 'on' ? 'Connected' : 'Disconnected', shore === 'on' ? 'good' : 'inactive')}</div>
      </div>
      ${this._row('Voltage', shoreV == null ? '—' : round1(shoreV), shoreV == null ? '' : 'V', '', 'sensor.rc_power_shore_voltage')}
      ${this._row('Current', shoreA == null ? '—' : round1(shoreA), shoreA == null ? '' : 'A', '', 'sensor.rc_power_shore_current')}
      ${this._row('Power', shoreW == null ? '—' : Math.round(shoreW), shoreW == null ? '' : 'W', '', 'sensor.rc_power_shore_power')}
    `;

    const alternatorTile = `
      <div style="margin-bottom: 10px;">
        ${this._badge('Idle', 'inactive')}
      </div>
      ${this._row('Voltage', altV == null ? '—' : round1(altV), altV == null ? '' : 'V')}
      ${this._row('Current', altA == null ? '—' : round1(altA), altA == null ? '' : 'A')}
      ${this._row('Power', altW == null ? '—' : Math.round(altW), altW == null ? '' : 'W')}
    `;

    const summary = `
      <div class="rc-grid" style="grid-template-columns: 1fr 1fr; gap: 12px;">
        <div>
          <div class="rc-label" style="margin-bottom:4px;">Net Power</div>
          <div class="rc-value"><div class="rc-value-num rc-value-md" style="color:var(--rc-good)">+${(solarW!=null && loadW!=null) ? Math.round(solarW-loadW) : '—'}</div><div class="rc-value-unit">W</div></div>
        </div>
        <div>
          <div class="rc-label" style="margin-bottom:4px;">Time to Full</div>
          <div class="rc-value"><div class="rc-value-num rc-value-md">—</div></div>
        </div>
        <div>
          <div class="rc-label" style="margin-bottom:4px;">Today Generation</div>
          <div class="rc-value"><div class="rc-value-num rc-value-md">—</div><div class="rc-value-unit">kWh</div></div>
        </div>
        <div>
          <div class="rc-label" style="margin-bottom:4px;">Today Consumption</div>
          <div class="rc-value"><div class="rc-value-num rc-value-md">—</div><div class="rc-value-unit">kWh</div></div>
        </div>
      </div>
    `;

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Power')}
        <div class="rc-grid">
          ${this._tile({title:'Battery', icon:'', content: batteryTop + batteryRows, className:'span-2'})}
          ${this._tile({title:'Solar', icon:'☼', content: solar})}
          ${this._tile({title:'Loads', icon:'⚡', content: loads})}
          ${this._tile({title:'Inverter', icon:'⎓', content: inverter})}
          ${this._tile({title:'Shore Power', icon:'⎍', content: shoreTile})}
          ${this._tile({title:'Alternator', icon:'⎈', content: alternatorTile})}
          ${this._tile({title:'Power Summary', icon:'', content: summary, className:'span-2'})}
        </div>
      </div>
    `;

  }
}

class RoamcoreNetworkPage extends RoamcoreBasePage {
  _render() {
    if (!this._root || !this._hass) return;

    const netStatus = this._getState('sensor.rc_net_wan_status');
    const netSource = this._getState('sensor.rc_net_wan_source');
    const down = this._num('sensor.rc_net_download', null);
    const up = this._num('sensor.rc_net_upload', null);
    const ping = this._num('sensor.rc_net_ping', null);

    const jitter = this._num('sensor.rc_net_jitter', null);
    const ploss = this._num('sensor.rc_net_packet_loss', null);
    const uptime = this._getState('sensor.rc_net_uptime');
    const lastDisc = this._getState('sensor.rc_net_last_disconnect');

    const dataTodayDown = this._num('sensor.rc_net_data_today_down', null);
    const dataTodayUp = this._num('sensor.rc_net_data_today_up', null);
    const dataMonthDown = this._num('sensor.rc_net_data_month_down', null);
    const dataMonthUp = this._num('sensor.rc_net_data_month_up', null);
    const dataMonthLimit = this._num('sensor.rc_net_data_month_limit', null);

    const slSig = this._num('sensor.rc_net_starlink_signal_quality', null);
    const cellProv = this._getState('sensor.rc_net_cellular_provider');
    const cellTech = this._getState('sensor.rc_net_cellular_technology');
    const cellSig = this._num('sensor.rc_net_cellular_signal', null);

    const lanDevs = this._num('sensor.rc_net_lan_devices', null);
    const lanWifi = this._num('sensor.rc_net_lan_wifi_clients', null);
    const lanEth = this._num('sensor.rc_net_lan_ethernet_clients', null);
    const ssid = this._getState('sensor.rc_net_ssid');
    const chan = this._getState('sensor.rc_net_channel');
    const freq = this._getState('sensor.rc_net_frequency');

    const rCpu = this._num('sensor.rc_router_cpu', null);
    const rMem = this._num('sensor.rc_router_memory', null);
    const rTemp = this._num('sensor.rc_router_temperature', null);
    const rUptime = this._getState('sensor.rc_router_uptime');
    const rFw = this._getState('sensor.rc_router_firmware');

    const status = (netStatus && netStatus !== 'unknown' && netStatus !== 'unavailable') ? netStatus : 'inactive';
    const c = rcStatusToColor(status);

    const connection = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px;">
        <div style="display:flex; gap:10px; align-items:center;">
          ${this._badge('Connected', status)}
        </div>
        <div style="text-align:right;">
          <div style="font-weight:800; text-transform:capitalize;">${rcCap(netSource)}</div>
          <div class="rc-label">Active Source</div>
        </div>
      </div>
      <div class="rc-grid" style="grid-template-columns: 1fr 1fr; gap: 10px;">
        <div>${this._row('Uptime', (uptime && uptime !== 'unknown' && uptime !== 'unavailable') ? uptime : '—')}</div>
        <div>${this._row('Last Disconnect', (lastDisc && lastDisc !== 'unknown' && lastDisc !== 'unavailable') ? lastDisc : '—')}</div>
      </div>
    `;

    const perf = `
      <div class="rc-grid" style="grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
        <div>
          <div class="rc-label">Download</div>
          <div class="rc-value"><div class="rc-value-num rc-value-md" data-more="sensor.rc_net_download" style="color:${c}">${down == null ? '—' : Math.round(down)}</div><div class="rc-value-unit">Mbps</div></div>
        </div>
        <div>
          <div class="rc-label">Upload</div>
          <div class="rc-value"><div class="rc-value-num rc-value-md" data-more="sensor.rc_net_upload">${up == null ? '—' : Math.round(up)}</div><div class="rc-value-unit">Mbps</div></div>
        </div>
      </div>
      ${this._row('Ping', ping == null ? '—' : Math.round(ping), 'ms', '', 'sensor.rc_net_ping')}
      ${this._row('Jitter', jitter == null ? '—' : Math.round(jitter), 'ms', '', 'sensor.rc_net_jitter')}
      ${this._row('Packet Loss', ploss == null ? '—' : round1(ploss), '%', '', 'sensor.rc_net_packet_loss')}
    `;

    const usagePct = (dataMonthDown != null && dataMonthLimit != null && dataMonthLimit > 0)
      ? Math.min(100, Math.max(0, (dataMonthDown / dataMonthLimit) * 100))
      : null;
    const usageColor = usagePct == null ? 'rgba(255,255,255,0.18)' : (usagePct > 90 ? 'var(--rc-bad)' : usagePct > 75 ? 'var(--rc-ok)' : 'var(--rc-good)');
    const dataUsage = `
      <div class="rc-label" style="margin-bottom:8px;">Monthly Usage</div>
      <div style="height: 10px; border-radius: 999px; background: rgba(255,255,255,0.08); overflow:hidden; margin-bottom: 8px;">
        <div style="height: 100%; width: ${usagePct == null ? 0 : Math.round(usagePct)}%; background: ${usageColor};"></div>
      </div>
      ${this._row('Today Down', dataTodayDown == null ? '—' : round1(dataTodayDown), 'GB')}
      ${this._row('Today Up', dataTodayUp == null ? '—' : round1(dataTodayUp), 'GB')}
      ${this._row('Month Down', dataMonthDown == null ? '—' : round1(dataMonthDown), 'GB')}
      ${this._row('Month Up', dataMonthUp == null ? '—' : round1(dataMonthUp), 'GB')}
    `;

    const starlink = `
      <div style="margin-bottom: 10px;">${this._badge('Connected', 'good')}</div>
      ${this._row('Signal', slSig == null ? '—' : Math.round(slSig), '%')}
      ${this._row('Obstructed', 'No')}
      ${this._row('Download', down == null ? '—' : Math.round(down), 'Mbps')}
      ${this._row('Upload', up == null ? '—' : Math.round(up), 'Mbps')}
      ${this._row('Latency', ping == null ? '—' : Math.round(ping), 'ms')}
    `;

    const cellular = `
      <div style="display:flex; gap:10px; align-items:center; margin-bottom: 10px;">
        ${this._badge(`${(cellProv && cellProv !== 'unknown' && cellProv !== 'unavailable') ? cellProv : '—'} • ${(cellTech && cellTech !== 'unknown' && cellTech !== 'unavailable') ? cellTech : '—'}`, 'ok')}
      </div>
      ${this._row('Signal', cellSig == null ? '—' : Math.round(cellSig), 'dBm')}
      ${this._row('Download', '—', 'Mbps')}
      ${this._row('Upload', '—', 'Mbps')}
      ${this._row('Latency', '—', 'ms')}
    `;

    const localNet = `
      <div class="rc-value" style="margin-bottom:10px;"><div class="rc-value-num rc-value-lg">${lanDevs == null ? '—' : Math.round(lanDevs)}</div><div class="rc-value-unit">devices</div></div>
      ${this._row('WiFi Clients', lanWifi == null ? '—' : Math.round(lanWifi))}
      ${this._row('Ethernet', lanEth == null ? '—' : Math.round(lanEth))}
      ${this._row('SSID', (ssid && ssid !== 'unknown' && ssid !== 'unavailable') ? ssid : '—')}
      ${this._row('Channel', (chan && chan !== 'unknown' && chan !== 'unavailable') ? `${chan} (${(freq && freq !== 'unknown' && freq !== 'unavailable') ? freq : '—'})` : '—')}
    `;

    const router = `
      <div style="margin-bottom: 10px;">${this._badge('Healthy', 'good')}</div>
      ${this._row('CPU', rCpu == null ? '—' : Math.round(rCpu), '%')}
      ${this._row('Memory', rMem == null ? '—' : Math.round(rMem), '%')}
      ${this._row('Temperature', rTemp == null ? '—' : Math.round(rTemp), '°C')}
      ${this._row('Uptime', (rUptime && rUptime !== 'unknown' && rUptime !== 'unavailable') ? rUptime : '—')}
      ${this._row('Firmware', (rFw && rFw !== 'unknown' && rFw !== 'unavailable') ? rFw : '—')}
    `;

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Network')}
        <div class="rc-grid">
          ${this._tile({title:'Connection Status', icon:'⌁', content: connection, className:'span-2'})}
          ${this._tile({title:'Performance', icon:'⟲', content: perf})}
          ${this._tile({title:'Data Usage', icon:'⛁', content: dataUsage})}
          ${this._tile({title:'Starlink', icon:'🛰', content: starlink})}
          ${this._tile({title:'Cellular', icon:'⋮', content: cellular})}
          ${this._tile({title:'Local Network', icon:'⌂', content: localNet})}
          ${this._tile({title:'Router Health', icon:'⎇', content: router})}
        </div>
      </div>
    `;

  }
}

customElements.define('roamcore-power-page', RoamcorePowerPage);


class RoamcoreLevelPage extends RoamcoreBasePage {
  _callCalibrate() {
    try {
      const ent = this._hass?.states?.['button.rc_system_level_calibrate'];
      if (ent && this._hass?.callService) {
        this._hass.callService('button', 'press', { entity_id: 'button.rc_system_level_calibrate' });
        return;
      }
      const sc = this._hass?.states?.['script.rc_system_level_calibrate'];
      if (sc && this._hass?.callService) {
        this._hass.callService('script', 'turn_on', { entity_id: 'script.rc_system_level_calibrate' });
        return;
      }
      alert('No calibrate entity found (expected button.rc_system_level_calibrate or script.rc_system_level_calibrate).');
    } catch (e) {
      console.warn('calibrate failed', e);
    }
  }

  _render() {
    if (!this._root || !this._hass) return;
    const pitch = this._num('sensor.rc_system_level_pitch_deg', null) ?? this._num('sensor.rc_system_level_pitch', null);
    const roll = this._num('sensor.rc_system_level_roll_deg', null) ?? this._num('sensor.rc_system_level_roll', null);
    const st = rcLevelStatusFromPitchRoll(pitch, roll);
    const c = rcStatusToColor(st.status);

    const pitchRot = (pitch == null ? 0 : Number(pitch));
    const rollRot = (roll == null ? 0 : Number(roll));

    const pitchTile = `
      <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap: 10px; height: 160px;">
        <div class="rc-vanwrap" style="transform: rotate(${(-pitchRot).toFixed(1)}deg)">${rcVanSideSvg()}</div>
        <div class="rc-value"><div class="rc-value-num rc-value-xl" style="color:${c}">${pitch == null ? '—' : Math.abs(pitch).toFixed(1)}</div><div class="rc-value-unit">°</div></div>
        <div class="rc-label">Pitch</div>
      </div>
    `;

    const rollTile = `
      <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap: 10px; height: 160px;">
        <div class="rc-vanwrap" style="transform: rotate(${(-rollRot).toFixed(1)}deg)">${rcVanBackSvg()}</div>
        <div class="rc-value"><div class="rc-value-num rc-value-xl" style="color:${c}">${roll == null ? '—' : Math.abs(roll).toFixed(1)}</div><div class="rc-value-unit">°</div></div>
        <div class="rc-label">Roll</div>
      </div>
    `;

    const statusTile = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div class="rc-label" style="margin-bottom:6px;">Status</div>
          <div style="font-size: 22px; font-weight: 900; color:${c}">${st.label}</div>
        </div>
        ${this._badge(st.label, st.status)}
      </div>
      <div style="height: 10px"></div>
      <button class="rc-btn" id="rc-calibrate">Calibrate</button>
      <div class="rc-label" style="margin-top:10px;">Tip: Calibrate on level ground before fine parking.</div>
    `;

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Level')}
        <div class="rc-grid">
          ${this._tile({title:'Pitch', icon:'', content: pitchTile})}
          ${this._tile({title:'Roll', icon:'', content: rollTile})}
          ${this._tile({title:'Calibration', icon:'⦿', content: statusTile, className:'span-2'})}
        </div>
      </div>
    `;

    const btn = this._root.querySelector('#rc-calibrate');
    if (btn) btn.addEventListener('click', () => this._callCalibrate());
  }
}

class RoamcoreMapPage extends RoamcoreBasePage {
  _render() {
    if (!this._root || !this._hass) return;

    // IMPORTANT: Keep a stable map container node across renders.
    // This avoids MapLibre/Leaflet being destroyed and recreated (flash, recenter, marker flicker).
    if (!this._rcMapHostEl) {
      const host = document.createElement('div');
      host.id = 'rc-map';
      host.style.height = '100%';
      host.style.width = '100%';
      host.style.borderRadius = '12px';
      host.style.overflow = 'hidden';
      this._rcMapHostEl = host;
    }

    const loc = this._getState('sensor.rc_map_location');
    const lat = this._num('sensor.rc_location_lat', null);
    const lon = this._num('sensor.rc_location_lon', null);
    const acc = this._num('sensor.rc_location_accuracy_m', null);
    const spd = this._num('sensor.rc_location_speed', null);
    const head = this._num('sensor.rc_location_heading_deg', null);
    const elev = this._num('sensor.rc_map_elevation_m', null) ?? this._num('sensor.rc_map_elevation', null);
    const distToday = this._num('sensor.rc_trip_distance_today_mi', null) ?? this._num('sensor.rc_trip_distance_today', null);
    const distTotal = this._num('sensor.rc_trip_distance_total_mi', null) ?? this._num('sensor.rc_trip_distance_total', null);
    const timeToday = this._getState('sensor.rc_trip_time_today');
    const timeTotal = this._getState('sensor.rc_trip_time_total');
    const segments = this._num('sensor.rc_trip_segments', null);
    const stops = this._num('sensor.rc_trip_stops', null);

    const trackerId = this._pickTrackerEntity();
    const tracker = trackerId ? (this._hass?.states?.[trackerId] || null) : null;
    const lastUpdated = tracker?.last_updated || tracker?.last_changed || null;
    const lastUpdatedTxt = lastUpdated ? new Date(lastUpdated).toLocaleString() : '—';

    const spdTxt = spd == null ? '—' : `${round1(spd)} mph`;
    const elevTxt = elev == null ? '—' : `${round1(elev)} m`;
    const distTodayTxt = distToday == null ? '—' : `${round1(distToday)} mi`;
    const distTotalTxt = distTotal == null ? '—' : `${round1(distTotal)} mi`;
    const timeTodayTxt = (timeToday && timeToday !== 'unknown' && timeToday !== 'unavailable') ? timeToday : '—';
    const timeTotalTxt = (timeTotal && timeTotal !== 'unknown' && timeTotal !== 'unavailable') ? timeTotal : '—';
    const stopsTodayTxt = stops == null ? '—' : `${Math.round(stops)}`;

    const mode = this._mapMode();

    // Below-map data tiles (do not touch the map itself when iterating on this section).
    const twStatus = this._getState('sensor.rc_trip_wrapped_latest_status');
    const twGenAt = this._getState('sensor.rc_trip_wrapped_latest_generated_at');
    const twStatusNorm = (twStatus && twStatus !== 'unknown' && twStatus !== 'unavailable') ? String(twStatus).toLowerCase() : 'unknown';
    const twGenTxt = (twGenAt && twGenAt !== 'unknown' && twGenAt !== 'unavailable')
      ? (() => { try { return new Date(twGenAt).toLocaleString(); } catch (e) { return String(twGenAt); } })()
      : '—';

    const twBadge = (() => {
      if (twStatusNorm === 'ok') return `<span style="font-weight:900; color: var(--rc-good)">✓ Ready</span>`;
      if (twStatusNorm === 'needs_setup') return `<span style="font-weight:900; color: rgba(255,255,255,0.75)">Setup required</span>`;
      if (twStatusNorm === 'missing') return `<span style="font-weight:900; color: rgba(255,255,255,0.55)">Not generated yet</span>`;
      return `<span style="font-weight:900; color: rgba(255,255,255,0.55)">Unknown</span>`;
    })();

    const tripWrappedTile = `
      <div style="margin-top: 14px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 14px; padding: 14px;">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
          <div>
            <div style="font-weight: 900; font-size: 14px;">Trip Wrapped</div>
          <div class="rc-label" style="margin-top:4px;">Generate a shareable recap (distance, drive time, top trip, etc.). Source-of-truth comes from Traccar reports.</div>
          <div class="rc-label" style="margin-top:8px;">Status: ${twBadge} · Last generated: <b>${twGenTxt}</b></div>
          </div>
          <div style="display:flex; gap:10px; flex-wrap:wrap; justify-content:flex-end;">
            <button class="rc-btn" id="rc-tripwrapped-generate-quick">Generate</button>
            <button class="rc-btn" id="rc-tripwrapped-open">Options</button>
            <a class="rc-btn" href="/local/roamcore/trip_wrapped/latest.html" target="_blank" rel="noreferrer">Open latest</a>
          </div>
        </div>
        <div id="rc-tripwrapped-preview" class="rc-label" style="margin-top:12px;">No summary loaded yet.</div>
      </div>
    `;

    const mapDataTiles = `
      <div style="margin-top: 14px; display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px;">
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 12px; min-width:0;">
          <div class="rc-label" style="font-weight:900; color: var(--rc-text);">Today’s trip</div>
          <div style="height:8px"></div>
          ${this._row('Distance', distTodayTxt)}
          ${this._row('Drive time', timeTodayTxt)}
          ${this._row('Stops', stopsTodayTxt)}
        </div>

        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 12px; min-width:0;">
          <div class="rc-label" style="font-weight:900; color: var(--rc-text);">Live position</div>
          <div style="height:8px"></div>
          ${this._row('Location', (loc && loc !== 'unknown' && loc !== 'unavailable') ? loc : '—')}
          ${this._row('Speed', spdTxt)}
          ${this._row('Elevation', elevTxt)}
          ${this._row('Last updated', lastUpdatedTxt)}
        </div>

        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 12px; min-width:0;">
          <div class="rc-label" style="font-weight:900; color: var(--rc-text);">Trip summary</div>
          <div style="height:8px"></div>
          ${this._row('Total distance', distTotalTxt)}
          ${this._row('Total drive time', timeTotalTxt)}
          ${this._row('Segments', segments == null ? '—' : `${Math.round(segments)}`)}
        </div>
      </div>
    `;

    const mapTile = `
      <div style="border-radius: 12px; overflow:hidden; border: 1px solid rgba(255,255,255,0.06); background: rgba(255,255,255,0.03); padding: 10px;">
        <div id="rc-map-inner" style="height: calc(100vh - 250px); min-height: 420px; max-height: 760px;">
          <div class="rc-label">Loading map…</div>
        </div>
      </div>
      <div style="display:flex; gap:8px; align-items:center; margin-top: 10px;">
        <div style="color: var(--rc-good); font-weight:900">⌖</div>
        <div style="font-weight:800; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(loc && loc!=='unknown' && loc!=='unavailable') ? loc : '—'}</div>
      </div>
      
      <div style="margin-top: 10px; display:flex; gap:10px; flex-wrap:wrap;">
        <a class="rc-btn" href="${this._traccarEmbedUrl()}" target="_blank" rel="noreferrer">Open Traccar (fullscreen)</a>
      </div>
      ${mapDataTiles}
      ${tripWrappedTile}
    `;

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Map')}
        <div class="rc-grid">
          ${this._tile({title:'Map', icon:'↗', content: mapTile, className:'span-2'})}
        </div>
      </div>
    `;

    // Mount map into placeholder.
    try {
      const inner = this._root.querySelector('#rc-map-inner');
      if (inner) {
        // Reattach the stable map host element (keeps map instance alive across renders).
        const el = this._rcMapHostEl;
        if (el && el.parentElement !== inner) {
          try { inner.replaceChildren(el); } catch (e) { try { inner.innerHTML = ''; inner.appendChild(el); } catch (e2) {} }
        }
        const lat = this._num('sensor.rc_location_lat', null);
        const lon = this._num('sensor.rc_location_lon', null);
        // NOTE: _render is not async; keep this promise-based.
        this._mountMapLibreMap(el, { lat, lon })
          .then((m) => {
            try {
              // Update marker to current location without moving the camera.
              const marker = el?._rcMapLibreMarker;
              if (marker && Number.isFinite(lon) && Number.isFinite(lat)) {
                marker.setLngLat([Number(lon), Number(lat)]);
              }
            } catch (e) {}
            // Route overlay (best-effort)
            try { Promise.resolve(this._overlayTraccarTrack(m)).catch(() => {}); } catch (e) {}
          })
          .catch(() => {
            // Absolute last resort: Leaflet fallback.
            const mapP = this._mountLeafletMap(el, { lat, lon, trackerId });
            Promise.resolve(mapP).then((map) => this._overlayTraccarTrack(map)).catch(() => {});
          });
      }
    } catch (e) {}

    // Trip Wrapped: async preview + modal.
    try {
      const btn = this._root.querySelector('#rc-tripwrapped-open');
      if (btn) btn.addEventListener('click', () => this._openTripWrappedModal());
      const quick = this._root.querySelector('#rc-tripwrapped-generate-quick');
      if (quick) quick.addEventListener('click', async () => {
        try {
          quick.disabled = true;
          // Generate using current helper values (From/To). Users can fine-tune in Options.
          await this._hass.callService('script', 'turn_on', { entity_id: 'script.rc_trip_wrapped_run' });
          // Refresh preview
          const prev = this._root.querySelector('#rc-tripwrapped-preview');
          if (prev) this._loadTripWrappedPreview(prev);
        } catch (e) {
          console.warn('quick trip wrapped generate failed', e);
        } finally {
          try { quick.disabled = false; } catch (e) {}
        }
      });
      const prev = this._root.querySelector('#rc-tripwrapped-preview');
      if (prev) this._loadTripWrappedPreview(prev);
    } catch (e) {}
  }

  async _loadTripWrappedPreview(el) {
    try {
      if (!el) return;
      // Prefer today's auto summary if available, otherwise latest.
      const tryUrls = [
        '/local/roamcore/trip_wrapped/today.json',
        '/local/roamcore/trip_wrapped/latest.json',
      ];
      let obj = null;
      for (const u of tryUrls) {
        try {
          const r = await fetch(u, { cache: 'no-cache' });
          if (!r.ok) continue;
          obj = await r.json();
          break;
        } catch (e) {}
      }
      if (!obj) {
        el.textContent = 'No Trip Wrapped data found yet. Tap Options → Generate.';
        return;
      }

      // If Trip Wrapped is in a degraded "needs setup" mode, surface a clear CTA.
      try {
        const meta = obj.meta || {};
        const notice = meta.notice || '';
        const status = String(meta.dataStatus || '').toLowerCase();
        if (status === 'needs_setup' || (notice && String(notice).trim())) {
          const msg = notice ? String(notice) : 'Trip Wrapped needs setup.';
          el.innerHTML = `${msg} <a href="${this._basePath()}/settings" target="_self" rel="noreferrer">Open setup</a>`;
          return;
        }
      } catch (e) {}

      const stats = obj.stats || {};
      const meta = obj.meta || {};
      const distM = Number(stats.totalDistanceM || 0);
      const durS = Number(stats.totalDurationS || 0);
      const distMi = (Number.isFinite(distM) ? distM / 1609.344 : 0);
      const h = Number.isFinite(durS) ? Math.floor(durS / 3600) : 0;
      const m = Number.isFinite(durS) ? Math.floor((durS % 3600) / 60) : 0;
      const trips = Number(meta.tripCount || 0);
      const gen = meta.generatedAt ? new Date(meta.generatedAt).toLocaleString() : '—';
      el.innerHTML = `Last generated: <b>${gen}</b> · Trips: <b>${trips}</b> · Distance: <b>${distMi.toFixed(1)} mi</b> · Drive time: <b>${h}:${String(m).padStart(2,'0')}</b>`;
    } catch (e) {
      try { el.textContent = 'Trip Wrapped preview failed to load.'; } catch (e2) {}
    }
  }

  _tripWrappedModalHtml() {
    // NOTE: keep this self-contained; do not touch the map container.
    return `
      <div class="rc-modal-backdrop" id="rc-tripwrapped-backdrop">
        <div class="rc-modal" role="dialog" aria-modal="true">
          <div class="rc-modal-head">
            <div style="font-weight:900; font-size: 16px;">Trip Wrapped</div>
            <button class="rc-btn" id="rc-tripwrapped-close">Close</button>
          </div>

          <div class="rc-label" style="margin-top:8px;">Pick a time range, then generate a shareable recap.</div>

          <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap;">
            <button class="rc-btn" id="rc-tripwrapped-preset-today">Today</button>
            <button class="rc-btn" id="rc-tripwrapped-preset-7d">Last 7 days</button>
            <button class="rc-btn" id="rc-tripwrapped-preset-30d">Last 30 days</button>
          </div>

          <div style="margin-top:14px; display:grid; grid-template-columns: 1fr 1fr; gap: 10px;">
            <div>
              <div class="rc-label" style="margin-bottom:6px;">From</div>
              <input id="rc-tripwrapped-from" type="datetime-local" class="rc-input" />
            </div>
            <div>
              <div class="rc-label" style="margin-bottom:6px;">To</div>
              <input id="rc-tripwrapped-to" type="datetime-local" class="rc-input" />
            </div>
          </div>

          <div style="margin-top:14px; display:grid; grid-template-columns: 1fr 1fr; gap: 10px;">
            <div>
              <div class="rc-label" style="margin-bottom:6px;">Export</div>
              <select id="rc-tripwrapped-export" class="rc-input">
                <option value="html_json" selected>HTML + JSON (recommended)</option>
                <option value="json">JSON only</option>
                <option value="html">HTML only</option>
              </select>
            </div>
            <div>
              <div class="rc-label" style="margin-bottom:6px;">After generate</div>
              <select id="rc-tripwrapped-after" class="rc-input">
                <option value="none" selected>Do nothing</option>
                <option value="open_latest">Open latest report</option>
              </select>
            </div>
          </div>

          <div style="margin-top:14px; display:grid; grid-template-columns: 1fr 1fr; gap: 10px;">
            <div>
              <div class="rc-label" style="margin-bottom:6px;">Map theme</div>
              <select id="rc-tripwrapped-theme" class="rc-input">
                <option value="light" selected>Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>
            <div>
              <div class="rc-label" style="margin-bottom:6px;">Open</div>
              <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <a class="rc-btn" href="/local/roamcore/trip_wrapped/latest.html" target="_blank" rel="noreferrer">Latest (light)</a>
                <a class="rc-btn" href="/local/roamcore/trip_wrapped/latest.html?theme=dark" target="_blank" rel="noreferrer">Latest (dark)</a>
              </div>
            </div>
          </div>

          <div class="rc-label" style="margin-top:12px;">Metrics come from Traccar (reports/trips/route/etc). RoamCore only renders the results.</div>

          <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap; justify-content:flex-end;">
            <button class="rc-btn" id="rc-tripwrapped-generate">Generate</button>
            <a class="rc-btn" href="/local/roamcore/trip_wrapped/latest.html" target="_blank" rel="noreferrer">Open latest</a>
          </div>

          <div id="rc-tripwrapped-status" class="rc-label" style="margin-top:10px;"></div>
        </div>
      </div>
    `;
  }

  _openTripWrappedModal() {
    try {
      if (!this._root) return;
      // Remove any existing modal.
      try { this._root.querySelector('#rc-tripwrapped-backdrop')?.remove?.(); } catch (e) {}

      const host = document.createElement('div');
      host.innerHTML = this._tripWrappedModalHtml();
      const backdrop = host.firstElementChild;
      if (!backdrop) return;
      this._root.appendChild(backdrop);

      const close = () => { try { backdrop.remove(); } catch (e) {} };
      backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });
      const closeBtn = backdrop.querySelector('#rc-tripwrapped-close');
      if (closeBtn) closeBtn.addEventListener('click', close);

      const fromEl = backdrop.querySelector('#rc-tripwrapped-from');
      const toEl = backdrop.querySelector('#rc-tripwrapped-to');
      const statusEl = backdrop.querySelector('#rc-tripwrapped-status');

      const setRange = (fromDate, toDate) => {
        try {
          const pad = (n) => String(n).padStart(2, '0');
          const fmt = (d) => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
          if (fromEl) fromEl.value = fmt(fromDate);
          if (toEl) toEl.value = fmt(toDate);
        } catch (e) {}
      };

      const now = new Date();
      setRange(new Date(now.getTime() - 7*24*3600*1000), now);

      const todayBtn = backdrop.querySelector('#rc-tripwrapped-preset-today');
      if (todayBtn) todayBtn.addEventListener('click', () => {
        const d = new Date();
        const from = new Date(d);
        from.setHours(0,0,0,0);
        setRange(from, d);
      });
      const d7Btn = backdrop.querySelector('#rc-tripwrapped-preset-7d');
      if (d7Btn) d7Btn.addEventListener('click', () => setRange(new Date(Date.now()-7*24*3600*1000), new Date()));
      const d30Btn = backdrop.querySelector('#rc-tripwrapped-preset-30d');
      if (d30Btn) d30Btn.addEventListener('click', () => setRange(new Date(Date.now()-30*24*3600*1000), new Date()));

      const genBtn = backdrop.querySelector('#rc-tripwrapped-generate');
      if (genBtn) genBtn.addEventListener('click', async () => {
        try {
          genBtn.disabled = true;
          if (statusEl) statusEl.textContent = 'Generating…';

          const fromVal = fromEl?.value;
          const toVal = toEl?.value;
          const fromIso = fromVal ? new Date(fromVal).toISOString() : null;
          const toIso = toVal ? new Date(toVal).toISOString() : null;
          if (!fromIso || !toIso) {
            if (statusEl) statusEl.textContent = 'Pick valid From/To dates.';
            return;
          }

          // Persist selected dates into HA helpers so the export command uses them.
          await this._hass.callService('input_text', 'set_value', { entity_id: 'input_text.rc_trip_wrapped_from', value: fromIso });
          await this._hass.callService('input_text', 'set_value', { entity_id: 'input_text.rc_trip_wrapped_to', value: toIso });

          // For now, export always generates both HTML+JSON (shell_command does both).
          // We keep the UI option for future, but do not branch yet.
          await this._hass.callService('script', 'turn_on', { entity_id: 'script.rc_trip_wrapped_run' });

          const theme = backdrop.querySelector('#rc-tripwrapped-theme')?.value || 'light';
          const url = theme === 'dark'
            ? '/local/roamcore/trip_wrapped/latest.html?theme=dark'
            : '/local/roamcore/trip_wrapped/latest.html';

          if (statusEl) statusEl.innerHTML = `Done. Open: <a href="${url}" target="_blank" rel="noreferrer">latest.html</a>`;

          // Refresh preview (best effort)
          try {
            const prev = this._root.querySelector('#rc-tripwrapped-preview');
            if (prev) this._loadTripWrappedPreview(prev);
          } catch (e) {}

          const after = backdrop.querySelector('#rc-tripwrapped-after')?.value;
          if (after === 'open_latest') {
            try { window.open(url, '_blank'); } catch (e) {}
          }
        } catch (e) {
          console.warn('trip wrapped generate failed', e);
          if (statusEl) statusEl.textContent = 'Generate failed (check Traccar credentials/config).';
        } finally {
          try { genBtn.disabled = false; } catch (e) {}
        }
      });
    } catch (e) {
      console.warn('open trip wrapped modal failed', e);
    }
  }

  async _overlayTraccarTrack(map) {
    try {
      if (!map || !this._hass) return;

      // 1) Choose a device
      const devices = await this._hass.callApi('get', 'roamcore/traccar_api/devices').catch(() => []);
      if (!Array.isArray(devices) || devices.length === 0) return;
      const deviceId = devices[0]?.id;
      if (!deviceId) return;

      // 2) Query route for last 6h
      const to = new Date();
      const from = new Date(to.getTime() - 6 * 3600 * 1000);
      const q = new URLSearchParams({
        deviceId: String(deviceId),
        from: from.toISOString(),
        to: to.toISOString(),
      });
      const positions = await this._hass.callApi('get', `roamcore/traccar_api/reports/route?${q.toString()}`).catch(() => []);
      if (!Array.isArray(positions) || positions.length < 2) return;

      // 3) Draw polyline
      const pts = positions
        .map(p => ({ lat: Number(p.latitude), lon: Number(p.longitude) }))
        .filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon));
      if (pts.length < 2) return;
      const latlngs = pts.map(p => [p.lat, p.lon]);

      // Leaflet is loaded by _mountLeafletMap.
      const L = window.L;
      if (!L) return;
      const line = L.polyline(latlngs, { color: '#43d17a', weight: 4, opacity: 0.9 });
      line.addTo(map);
    } catch (e) {
      return;
    }
  }
}

class RoamcoreLocationPage extends RoamcoreBasePage {
  _render() {
    if (!this._root || !this._hass) return;

    const lat = this._num('sensor.rc_location_lat', null);
    const lon = this._num('sensor.rc_location_lon', null);
    const acc = this._num('sensor.rc_location_accuracy_m', null) ?? this._num('sensor.rc_location_accuracy', null);
    const src = this._getState('sensor.rc_location_source');

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Location')}
        <div class="rc-grid" style="grid-template-columns: 1fr;">
          ${this._tile({
            title: 'Current Fix',
            icon: '📍',
            content: `
              ${this._row('Latitude', lat == null ? '—' : lat)}
              ${this._row('Longitude', lon == null ? '—' : lon)}
              ${this._row('Accuracy', acc == null ? '—' : Math.round(acc), acc == null ? '' : 'm')}
              ${this._row('Source', (src && src !== 'unknown' && src !== 'unavailable') ? src : '—')}
              <button class="rc-btn" data-nav="${this._basePath()}/location" style="margin-top:10px;">Refresh</button>
            `
          })}

          ${this._tile({
            title: 'Map',
            icon: '🗺',
            content: `
              <div id="rc-location-map" style="height:360px; border-radius:12px; overflow:hidden;"></div>
              <div class="rc-label" style="margin-top:8px;">Breadcrumb trail: last 6 hours (from HA history).</div>
            `
          })}
        </div>
      </div>
    `;
    this._wireNav();

    // Mount Leaflet map.
    try {
      const el = this._root.querySelector('#rc-location-map');
      const trackerId = this._pickTrackerEntity();
      const latN = Number(lat);
      const lonN = Number(lon);
      this._mountLeafletMap(el, { lat: latN, lon: lonN, trackerId });
    } catch (e) {}
  }
}

// -----------------
// Setup Wizard (revamp)
// -----------------
// Design goals:
// - 4 tiles (Owner, Map, Trip Wrapped, Victron)
// - Each tile shows: status + stepper + CTAs
// - Readiness is driven by rc_setup_* sensors so the wizard is deterministic
// - Incremental: this is additive; the legacy YAML setup view can remain as fallback

class RoamcoreSetupPage extends RoamcoreBasePage {
  constructor() {
    super();
    this._victronConnectEl = null;
  }

  _css() {
    return super._css() + `
      .rc-setup-hero { margin: 2px 0 12px; }
      .rc-setup-h1 { font-size: 22px; font-weight: 950; letter-spacing: 0.2px; }
      .rc-setup-h2 { margin-top: 6px; color: var(--rc-muted); font-size: 13px; line-height: 1.35; }
      .rc-setup-toprow { display:flex; align-items:center; justify-content:space-between; gap: 10px; margin-top: 10px; flex-wrap: wrap; }
      .rc-pill2 { display:inline-flex; align-items:center; gap: 8px; padding: 6px 10px; border-radius: 999px; border: 1px solid rgba(255,255,255,0.10); background: rgba(255,255,255,0.04); font-weight: 900; font-size: 12px; }
      .rc-pill2 b { font-weight: 950; }

      .rc-steps { display:flex; flex-direction:column; gap: 10px; margin-top: 10px; }
      .rc-step { display:flex; gap: 10px; align-items:flex-start; }
      .rc-step-dot { width: 18px; height: 18px; border-radius: 999px; border: 1px solid rgba(255,255,255,0.12); display:inline-flex; align-items:center; justify-content:center; font-size: 12px; flex: 0 0 auto; margin-top: 1px; }
      .rc-step-main { display:flex; flex-direction:column; gap: 2px; }
      .rc-step-title { font-weight: 900; font-size: 13px; }
      .rc-step-sub { color: var(--rc-muted); font-size: 12px; line-height: 1.35; }
      .rc-step-actions { margin-top: 6px; display:flex; flex-wrap:wrap; gap: 8px; }

      .rc-btn-row { display:flex; gap: 10px; flex-wrap:wrap; margin-top: 12px; }
      .rc-btn-mini { width: auto; padding: 10px 12px; border-radius: 12px; font-weight: 900; }
      .rc-btn-ghost { background: rgba(255,255,255,0.03); }

      details.rc-details { margin-top: 10px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); background: rgba(0,0,0,0.18); overflow:hidden; }
      details.rc-details > summary { cursor:pointer; list-style:none; padding: 10px 12px; font-weight: 900; color: rgba(255,255,255,0.86); }
      details.rc-details > summary::-webkit-details-marker { display:none; }
      .rc-details-body { padding: 10px 12px; border-top: 1px solid rgba(255,255,255,0.08); }

      /* Better mobile layout: single column */
      @media (max-width: 680px) {
        .rc-grid { grid-template-columns: 1fr; }
      }
    `;
  }

  _isOn(entityId) {
    const v = this._getState(entityId);
    return String(v || '').toLowerCase() === 'on';
  }

  _hasValue(entityId) {
    const v = this._getState(entityId);
    const s = (v === null || v === undefined) ? '' : String(v);
    const t = s.trim().toLowerCase();
    return !!(t && t !== 'unknown' && t !== 'unavailable' && t !== 'none');
  }

  _step({ label, ok, sub = '', actionsHtml = '' }) {
    const status = ok === true ? 'good' : (ok === false ? 'bad' : 'inactive');
    const c = rcStatusToColor(status);
    const dot = ok === true ? '✓' : (ok === false ? '•' : '–');
    const subHtml = sub ? `<div class="rc-step-sub">${sub}</div>` : '';
    const actHtml = actionsHtml ? `<div class="rc-step-actions">${actionsHtml}</div>` : '';
    return `
      <div class="rc-step">
        <div class="rc-step-dot" style="border-color:${c}; color:${c}; background: color-mix(in srgb, ${c} 14%, transparent)">${dot}</div>
        <div class="rc-step-main">
          <div class="rc-step-title">${label}</div>
          ${subHtml}
          ${actHtml}
        </div>
      </div>
    `;
  }

  _tileStatusPill({ ok, okLabel = 'Ready', badLabel = 'Needs setup' }) {
    const status = ok ? 'good' : 'ok';
    return this._badge(ok ? okLabel : badLabel, status);
  }

  _render() {
    if (!this._root || !this._hass) return;

    // Wizard tiles
    const powerOk = this._isOn('binary_sensor.rc_setup_victron_ready');
    const netOk = this._isOn('binary_sensor.rc_setup_networking_ready');
    const lvlOk = this._isOn('binary_sensor.rc_setup_levelling_ready');
    const mapOk = this._isOn('binary_sensor.rc_setup_map_ready');
    const done = (powerOk ? 1 : 0) + (netOk ? 1 : 0) + (lvlOk ? 1 : 0) + (mapOk ? 1 : 0);

    // General items (not tiles)
    const ownerName = this._getState('input_text.rc_owner_name');
    const ownerOk = this._isOn('binary_sensor.rc_setup_owner_ready');
    const demoMode = this._getState('input_boolean.rc_demo_mode');
    const demoOn = String(demoMode || '').toLowerCase() === 'on';

    // Power details
    const backendOnline = this._isOn('binary_sensor.rc_system_power_backend_connected');
    const backendStatus = this._getState('sensor.rc_system_power_backend_status');
    const snapshotState = this._getState('sensor.rc_system_power_backend_snapshot_state');
    const devices = this._getState('sensor.rc_system_power_backend_devices');
    const topics = this._getState('sensor.rc_system_power_backend_topics');
    const soc = this._getState('sensor.rc_power_battery_soc');
    const solar = this._getState('sensor.rc_power_solar_power');

    // Network details
    const wan = this._getState('sensor.rc_openwrt_active_wan');
    const internet = this._getState('sensor.rc_openwrt_internet');
    const wanStatus = this._getState('sensor.rc_net_wan_status');
    const ping = this._getState('sensor.rc_net_ping');

    // Level details
    const pitchSrc = this._getState('sensor.rc_level_pitch_source');
    const rollSrc = this._getState('sensor.rc_level_roll_source');
    const pitch = this._getState('sensor.rc_level_pitch_deg');
    const roll = this._getState('sensor.rc_level_roll_deg');

    // Map details
    const trackerOk = this._hasValue('input_text.rc_location_tracker_entity');
    const latOk = this._hasValue('sensor.rc_location_lat');
    const lonOk = this._hasValue('sensor.rc_location_lon');
    const lat = this._getState('sensor.rc_location_lat');
    const lon = this._getState('sensor.rc_location_lon');

    // Trip Wrapped under Map
    const tripOk = this._isOn('binary_sensor.rc_setup_trip_wrapped_ready');
    const traccarBaseOk = this._hasValue('input_text.rc_traccar_base_url');
    const devId = Number(this._getState('input_number.rc_traccar_device_id'));
    const devIdOk = Number.isFinite(devId) && devId > 0;
    const tokenPresent = this._isOn('binary_sensor.rc_setup_traccar_user_token_present');
    const latestReady = this._isOn('binary_sensor.rc_trip_wrapped_latest_ready');
    const latestStatus = this._getState('sensor.rc_trip_wrapped_latest_status');

    const generalBlock = `
      <details class="rc-details" ${(!ownerOk || demoOn) ? 'open' : ''}>
        <summary>General setup</summary>
        <div class="rc-details-body">
          <div class="rc-steps">
            ${this._step({
              label: 'Owner name (used in Trip Wrapped)',
              ok: ownerOk,
              sub: ownerName && !rcIsMissingState(ownerName) ? `Current: <b>${String(ownerName)}</b>` : 'Set a name for reports.',
              actionsHtml: `<button class="rc-btn rc-btn-mini" data-more="input_text.rc_owner_name">Edit</button>`
            })}
            ${this._step({
              label: 'Demo mode',
              ok: demoOn ? false : true,
              sub: demoOn ? 'Demo mode is ON (some tiles may show demo values).' : 'Demo mode is OFF.',
              actionsHtml: `<button class="rc-btn rc-btn-mini rc-btn-ghost" data-call="input_boolean.toggle" data-entity="input_boolean.rc_demo_mode">Toggle</button>`
            })}
          </div>
        </div>
      </details>
    `;

    const powerTile = this._tile({
      title: 'Power',
      icon: '⚡',
      content: `
        <div style="display:flex; align-items:center; justify-content:space-between; gap: 10px;">
          ${this._tileStatusPill({ ok: powerOk, okLabel: 'Ready', badLabel: 'Connect Victron' })}
          <div class="rc-label" style="text-align:right;">${backendOnline ? 'Backend online' : 'Backend offline'}</div>
        </div>
        <div class="rc-steps">
          ${this._step({
            label: 'Connect a Victron GX device',
            ok: backendOnline ? true : null,
            sub: 'Use auto-discovery or manual host/IP if discovery fails.',
            actionsHtml: `<button class="rc-btn rc-btn-mini rc-btn-ghost" data-nav="${this._basePath()}/power">Open Power page</button>`
          })}
          ${this._step({
            label: 'Verify snapshot/telemetry is flowing',
            ok: powerOk,
            sub: `status: <b>${rcIsMissingState(backendStatus) ? '—' : backendStatus}</b> · snapshot: <b>${rcIsMissingState(snapshotState) ? '—' : snapshotState}</b> · devices: <b>${rcIsMissingState(devices) ? '—' : devices}</b> · topics: <b>${rcIsMissingState(topics) ? '—' : topics}</b>`,
          })}
          ${this._step({
            label: 'Quick sanity check',
            ok: !['unknown', 'unavailable', 'none', ''].includes(String(soc || '').toLowerCase()),
            sub: `SOC: <b>${rcIsMissingState(soc) ? '—' : soc}%</b> · Solar: <b>${rcIsMissingState(solar) ? '—' : solar} W</b>`,
          })}
        </div>

        <details class="rc-details" ${backendOnline ? '' : 'open'}>
          <summary>Victron connect</summary>
          <div class="rc-details-body">
            <div class="rc-victron-mount"></div>
          </div>
        </details>
      `,
      className: 'span-2'
    });

    const networkTile = this._tile({
      title: 'Network',
      icon: '📶',
      content: `
        <div style="display:flex; align-items:center; justify-content:space-between; gap: 10px;">
          ${this._tileStatusPill({ ok: netOk, okLabel: 'Ready', badLabel: 'Needs setup' })}
          <div class="rc-label" style="text-align:right;">WAN: <b>${rcIsMissingState(wan) ? '—' : wan}</b> · Internet: <b>${rcIsMissingState(internet) ? '—' : internet}</b></div>
        </div>
        <div class="rc-steps">
          ${this._step({
            label: 'Ensure router backend is connected',
            ok: netOk,
            sub: 'This tile only goes green when the OpenWrt sensors are alive.',
            actionsHtml: `<button class="rc-btn rc-btn-mini rc-btn-ghost" data-nav="${this._basePath()}/network">Open Network page</button>`
          })}
          ${this._step({
            label: 'Connectivity sanity check',
            ok: (String(wanStatus || '').toLowerCase() === 'online') ? true : null,
            sub: `WAN status: <b>${rcIsMissingState(wanStatus) ? '—' : wanStatus}</b> · Ping: <b>${rcIsMissingState(ping) ? '—' : ping} ms</b>`,
          })}
        </div>
      `
    });

    const levelTile = this._tile({
      title: 'Level',
      icon: '🧭',
      content: `
        <div style="display:flex; align-items:center; justify-content:space-between; gap: 10px;">
          ${this._tileStatusPill({ ok: lvlOk, okLabel: 'Ready', badLabel: 'Needs sensors' })}
          <div class="rc-label" style="text-align:right;">Pitch: <b>${rcIsMissingState(pitch) ? '—' : pitch}°</b> · Roll: <b>${rcIsMissingState(roll) ? '—' : roll}°</b></div>
        </div>
        <div class="rc-steps">
          ${this._step({
            label: 'Auto-detect sensors',
            ok: (String(pitchSrc || '') !== 'none' && String(rollSrc || '') !== 'none') ? true : false,
            sub: `Pitch source: <b>${rcIsMissingState(pitchSrc) ? '—' : pitchSrc}</b> · Roll source: <b>${rcIsMissingState(rollSrc) ? '—' : rollSrc}</b>`
          })}
          ${this._step({
            label: 'If needed: map pitch/roll entities',
            ok: lvlOk,
            sub: 'Paste entity ids. These override auto-detection when valid.',
            actionsHtml: `
              <button class="rc-btn rc-btn-mini" data-more="input_text.rc_level_pitch_entity">Set pitch entity</button>
              <button class="rc-btn rc-btn-mini" data-more="input_text.rc_level_roll_entity">Set roll entity</button>
            `
          })}
          ${this._step({
            label: 'Calibrate (optional)',
            ok: null,
            sub: 'Press calibrate when the vehicle is on level ground to set offsets.',
            actionsHtml: `<button class="rc-btn rc-btn-mini rc-btn-ghost" data-more="button.rc_level_calibrate">Calibrate</button>`
          })}
        </div>
      `
    });

    const mapTile = this._tile({
      title: 'Map',
      icon: '🗺',
      content: `
        <div style="display:flex; align-items:center; justify-content:space-between; gap: 10px;">
          ${this._tileStatusPill({ ok: mapOk, okLabel: 'Ready', badLabel: 'Needs GPS' })}
          <div class="rc-label" style="text-align:right;">${(latOk && lonOk) ? 'GPS fix OK' : (trackerOk ? 'Waiting for GPS' : 'Tracker not set')}</div>
        </div>
        <div class="rc-steps">
          ${this._step({
            label: 'Choose tracker entity',
            ok: trackerOk,
            sub: 'Set the device_tracker used as your location source.',
            actionsHtml: `
              <button class="rc-btn rc-btn-mini" data-more="input_text.rc_location_tracker_entity">Edit</button>
              <button class="rc-btn rc-btn-mini rc-btn-ghost" data-nav="${this._basePath()}/location">Open Location</button>
            `
          })}
          ${this._step({
            label: 'Confirm coordinates (lat/lon)',
            ok: mapOk,
            sub: `Current: ${(latOk && lonOk) ? `<b>${lat}, ${lon}</b>` : '—'}`,
            actionsHtml: `<button class="rc-btn rc-btn-mini rc-btn-ghost" data-nav="${this._basePath()}/map">Open Map page</button>`
          })}
        </div>

        <details class="rc-details" ${(!tripOk || String(latestStatus || '') === 'needs_setup') ? 'open' : ''}>
          <summary>Trip Wrapped (optional, inside Map)</summary>
          <div class="rc-details-body">
            <div class="rc-steps">
              ${this._step({
                label: 'Set Traccar base URL',
                ok: traccarBaseOk,
                sub: 'Where the Traccar server is reachable from Home Assistant.',
                actionsHtml: `<button class="rc-btn rc-btn-mini" data-more="input_text.rc_traccar_base_url">Edit</button>`
              })}
              ${this._step({
                label: 'Set device ID',
                ok: devIdOk,
                sub: devIdOk ? `Using device ID: <b>${devId}</b>` : 'Must be a positive number.',
                actionsHtml: `<button class="rc-btn rc-btn-mini" data-more="input_number.rc_traccar_device_id">Edit</button>`
              })}
              ${this._step({
                label: 'Save a Traccar user token (recommended)',
                ok: tokenPresent,
                sub: tokenPresent ? 'Token present in secrets.yaml.' : 'Paste token then save securely.',
                actionsHtml: `
                  <button class="rc-btn rc-btn-mini" data-more="input_text.rc_setup_traccar_user_token">Paste token</button>
                  <button class="rc-btn rc-btn-mini rc-btn-ghost" data-call="script.turn_on" data-entity="script.rc_setup_save_traccar_user_token">Save token securely</button>
                `
              })}
              ${this._step({
                label: 'Generate a test report',
                ok: latestReady,
                sub: `Latest status: <b>${rcIsMissingState(latestStatus) ? '—' : latestStatus}</b>`,
                actionsHtml: `
                  <button class="rc-btn rc-btn-mini" data-call="script.turn_on" data-entity="script.rc_trip_wrapped_run_today">Generate (Today)</button>
                  <a class="rc-btn rc-btn-mini rc-btn-ghost" href="/local/roamcore/trip_wrapped/latest.html" target="_blank" rel="noopener">Open latest</a>
                `
              })}
            </div>
          </div>
        </details>
      `
    });

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Setup')}

        <div class="rc-setup-hero">
          <div class="rc-setup-h1">RoamCore Setup</div>
          <div class="rc-setup-h2">Complete the four tiles below. Each tile turns green when ready.</div>
          <div class="rc-setup-toprow">
            <span class="rc-pill2">Configured: <b>${done}/4</b></span>
            ${done === 4 ? `<span class="rc-pill2" style="border-color: rgba(67,209,122,0.35); background: rgba(67,209,122,0.10)">All tiles ready</span>` : ''}
          </div>
          ${this._setupBanner()}
          ${generalBlock}
        </div>

        <div class="rc-grid">
          ${powerTile}
          ${networkTile}
          ${levelTile}
          ${mapTile}
        </div>

        <div style="margin-top: 12px;">
          <div class="rc-btn-row">
            <button class="rc-btn rc-btn-mini rc-btn-ghost" data-nav="${this._basePath()}/home">Back to dashboard</button>
            <button class="rc-btn rc-btn-mini rc-btn-ghost" data-nav="${this._basePath()}/settings">Dashboard settings</button>
            <button class="rc-btn rc-btn-mini rc-btn-ghost" data-nav="${this._basePath()}/diagnostics">Diagnostics</button>
          </div>
        </div>
      </div>
    `;

    // Mount (and preserve) the Victron connect card into its placeholder.
    // We keep a single element instance so user input isn't wiped on every HA state update.
    try {
      const mount = this._root.querySelector('.rc-victron-mount');
      if (mount) {
        if (!this._victronConnectEl) {
          const el = document.createElement('roamcore-victron-connect');
          if (typeof el.setConfig === 'function') el.setConfig({ title: 'Victron (Connect)' });
          this._victronConnectEl = el;
        }
        this._victronConnectEl.hass = this._hass;
        if (this._victronConnectEl.parentElement !== mount) {
          mount.appendChild(this._victronConnectEl);
        }
      }
    } catch (e) {}
  }
}

class RoamcoreSettingsPage extends RoamcoreBasePage {
  _render() {
    if (!this._root || !this._hass) return;

    const tracker = this._getState('input_text.rc_location_tracker_entity');
    const weather = this._getState('input_text.rc_weather_entity_id');
    const tz = this._getState('input_text.rc_time_zone_override');

    const prog = this._getState('sensor.rc_setup_progress');
    const ownerReady = this._getState('binary_sensor.rc_setup_owner_ready');
    const mapReady = this._getState('binary_sensor.rc_setup_map_ready');
    const tripReady = this._getState('binary_sensor.rc_setup_trip_wrapped_ready');
    const victronReady = this._getState('binary_sensor.rc_setup_victron_ready');

    const demoMode = this._getState('input_boolean.rc_demo_mode');

    // Traccar / Trip tracking
    const trBase = this._getState('input_text.rc_traccar_base_url');
    const trDev = this._getState('input_number.rc_traccar_device_id');
    const trTokenPresent = this._getState('binary_sensor.rc_setup_traccar_user_token_present');
    const trUiReachable = this._getState('binary_sensor.rc_traccar_ui_reachable');
    const twStatus = this._getState('sensor.rc_trip_wrapped_latest_status');

    const isOn = (v) => String(v || '').toLowerCase() === 'on';
    const badge = (label, ok) => `<span style="display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius: 999px; border: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.03); font-weight: 800; font-size: 12px; color: ${ok ? 'var(--rc-good)' : 'rgba(255,255,255,0.55)'}">${ok ? '✓' : '•'} ${label}</span>`;

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Settings')}
        <div class="rc-grid" style="grid-template-columns: 1fr;">
          ${this._tile({
            title: 'Setup',
            icon: '✨',
            content: `
              <div class="rc-label" style="margin-bottom:8px;">Complete setup to unlock the full RoamCore experience.</div>
              ${this._row('Progress', (prog && prog !== 'unknown' && prog !== 'unavailable') ? prog : '—')}
              <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:10px;">
                ${badge('Owner', isOn(ownerReady))}
                ${badge('Map', isOn(mapReady))}
                ${badge('Trip Wrapped', isOn(tripReady))}
                ${badge('Victron', isOn(victronReady))}
              </div>
              <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
                <button class="rc-btn" data-nav="${this._basePath()}/setup">Open setup wizard</button>
              </div>
            `
          })}
          ${this._tile({
            title: 'Demo Mode',
            icon: '🎭',
            content: `
              <div class="rc-label" style="margin-bottom:8px;">Show demo values in RoamCore tiles when critical sensors are missing.</div>
              ${this._row('Demo mode', isOn(demoMode) ? 'On' : 'Off')}
              <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
                <button class="rc-btn" data-call="input_boolean.toggle" data-entity="input_boolean.rc_demo_mode">Toggle demo mode</button>
              </div>
            `
          })}
          ${this._tile({
            title: 'RoamCore Helpers',
            icon: '⚙',
            content: `
              <div class="rc-label" style="margin-bottom:8px;">Edit these in HA → Settings → Devices & services → Helpers.</div>
              ${this._row('Location tracker entity', (tracker && tracker !== 'unknown' && tracker !== 'unavailable') ? tracker : '—')}
              ${this._row('Weather entity', (weather && weather !== 'unknown' && weather !== 'unavailable') ? weather : '—')}
              ${this._row('Time zone override', (tz && tz.trim()) ? tz : '—')}
            `
          })}

          ${this._tile({
            title: 'Traccar (Trip tracking)',
            icon: '📍',
            content: `
              <div class="rc-label" style="margin-bottom:10px;">If the route/Trip Wrapped stops updating, follow the reconnect steps below.</div>
              ${this._row('Base URL', (trBase && trBase !== 'unknown' && trBase !== 'unavailable') ? trBase : '—')}
              ${this._row('Device ID', (trDev && trDev !== 'unknown' && trDev !== 'unavailable') ? trDev : '—')}
              ${this._row('User token saved', isOn(trTokenPresent) ? 'Yes' : 'No')}
              ${this._row('UI reachable', isOn(trUiReachable) ? 'Yes' : 'No')}
              ${this._row('Trip Wrapped status', (twStatus && twStatus !== 'unknown' && twStatus !== 'unavailable') ? twStatus : '—')}

              <details class="rc-details" open>
                <summary>Reconnect steps (copy/paste friendly)</summary>
                <div class="rc-details-body">
                  <div class="rc-label">1) Confirm the Traccar server URL + device id.</div>
                  <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:8px;">
                    <button class="rc-btn" data-more="input_text.rc_traccar_base_url">Edit base URL</button>
                    <button class="rc-btn" data-more="input_number.rc_traccar_device_id">Edit device id</button>
                  </div>

                  <div class="rc-label" style="margin-top:12px;">2) Refresh your Traccar user token (recommended) and save it securely.</div>
                  <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:8px;">
                    <button class="rc-btn" data-more="input_text.rc_setup_traccar_user_token">Paste new token</button>
                    <button class="rc-btn" data-call="script.turn_on" data-entity="script.rc_setup_save_traccar_user_token">Save token</button>
                  </div>
                  <div class="rc-label" style="margin-top:10px;">3) Generate a test report.</div>
                  <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:8px;">
                    <button class="rc-btn" data-call="script.turn_on" data-entity="script.rc_trip_wrapped_run_today">Generate (Today)</button>
                    <a class="rc-btn rc-btn-ghost" href="/local/roamcore/trip_wrapped/latest.html" target="_blank" rel="noopener">Open latest</a>
                  </div>
                  <div class="rc-label" style="margin-top:10px;">If it still fails: open Setup → Map → Trip Wrapped to recheck each input.</div>
                  <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:8px;">
                    <button class="rc-btn rc-btn-ghost" data-nav="${this._basePath()}/setup">Open setup wizard</button>
                    <a class="rc-btn rc-btn-ghost" href="${this._traccarEmbedUrl()}" target="_blank" rel="noreferrer">Open Traccar UI</a>
                  </div>
                </div>
              </details>
            `
          })}

          ${this._tile({
            title: 'Advanced',
            icon: '🧰',
            content: `
              <div class="rc-label">Open HA configuration for deeper setup.</div>
              <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:10px;">
                <button class="rc-btn" data-nav="${this._basePath()}/diagnostics" style="flex:1; min-width: 220px;">Diagnostics</button>
                <button class="rc-btn" data-nav="/config" style="flex:1; min-width: 220px;">Open HA Settings</button>
              </div>
            `
          })}
        </div>
      </div>
    `;
  }
}

class RoamcoreDiagnosticsPage extends RoamcoreBasePage {
  constructor() {
    super();
    this._diag = null;
    this._diagErr = null;
    this._diagLoading = false;
    this._diagFetchedAt = 0;
    this._copyStatus = '';
  }

  _css() {
    return super._css() + `
      .rc-pre {
        white-space: pre-wrap;
        word-break: break-word;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        font-size: 12px;
        line-height: 1.35;
        padding: 10px 12px;
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.08);
        background: rgba(0,0,0,0.25);
        color: rgba(255,255,255,0.88);
      }
      .rc-kv { display:flex; flex-direction:column; gap:8px; }
      .rc-pillrow2 { display:flex; flex-wrap:wrap; gap:8px; margin-top: 8px; }
      .rc-mini { font-size: 12px; color: var(--rc-muted); font-weight: 650; }
      .rc-linkrow { display:flex; justify-content:space-between; align-items:center; gap: 10px; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.06); }
      .rc-linkrow:last-child { border-bottom: 0; }
      .rc-linkname { font-weight: 800; font-size: 13px; }
      .rc-link { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; font-size: 12px; color: rgba(255,255,255,0.72); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width: 62vw; }
      .rc-btn2 { display:inline-flex; align-items:center; justify-content:center; padding: 10px 12px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.10); background: rgba(255,255,255,0.05); color: var(--rc-text); font-weight: 900; cursor:pointer; }
      .rc-btn2:hover { filter: brightness(1.06); }
      .rc-btn2:disabled { opacity: 0.6; cursor: not-allowed; }
    `;
  }

  _esc(s) {
    const v = (s === null || s === undefined) ? '' : String(s);
    return v
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  _stateObj(entityId) {
    try { return this._hass?.states?.[entityId] || null; } catch (e) { return null; }
  }

  _presenceBadge(label, entityId) {
    const st = this._stateObj(entityId);
    if (!st) return this._badge(label, 'inactive');
    const v = String(st.state || '').toLowerCase();
    if (v === 'on' || v === 'true' || v === '1') return this._badge(label, 'good');
    if (v === 'off' || v === 'false' || v === '0') return this._badge(label, 'bad');
    if (v === 'unknown' || v === 'unavailable' || v === '') return this._badge(label, 'inactive');
    return this._badge(label, 'ok');
  }

  async _fetchDiagnostics({ includeRcDump = false, force = false } = {}) {
    try {
      if (!this._hass) return;
      if (this._diagLoading) return;

      const age = Date.now() - (this._diagFetchedAt || 0);
      if (!force && this._diag && age < 15000 && !includeRcDump) return;

      this._diagLoading = true;
      this._diagErr = null;
      this._render();

      const qs = includeRcDump ? '?include_rc_dump=1' : '';
      const data = await this._hass.callApi('get', `roamcore/diagnostics${qs}`);
      this._diag = data;
      this._diagFetchedAt = Date.now();
    } catch (e) {
      this._diagErr = String(e?.message || e || 'Diagnostics fetch failed');
    } finally {
      this._diagLoading = false;
      this._render();
    }
  }

  async _copyText(text) {
    try {
      const s = String(text || '');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(s);
        return true;
      }
      // Fallback for older WebViews
      const ta = document.createElement('textarea');
      ta.value = s;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      ta.style.top = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return !!ok;
    } catch (e) {
      return false;
    }
  }

  async _copyBundle() {
    this._copyStatus = '';
    this._render();
    try {
      await this._fetchDiagnostics({ includeRcDump: true, force: true });
      const bundle = this._diag;
      const text = JSON.stringify(bundle || { error: 'no_bundle' }, null, 2);
      const ok = await this._copyText(text);
      this._copyStatus = ok ? 'Copied to clipboard.' : 'Copy failed (clipboard blocked).';
    } catch (e) {
      this._copyStatus = `Copy failed: ${String(e?.message || e)}`;
    }
    this._render();
  }

  _render() {
    if (!this._root || !this._hass) return;

    // Kick off an initial fetch once per mount.
    if (!this._diag && !this._diagLoading && !this._diagErr) {
      this._fetchDiagnostics({ includeRcDump: false, force: false });
    }

    const diag = this._diag || {};
    const install = diag.install || {};
    const ii = install.install_info || {};
    const pm = install.provisioned_marker || {};
    const opts = diag?.roamcore?.config_entry?.options || {};

    const keyEntities = Array.isArray(diag?.entities?.key) ? diag.entities.key : [];

    const openLink = (url, label) => `<a href="${this._esc(url)}" target="_blank" rel="noreferrer" style="color:rgba(255,255,255,0.92); text-decoration: none; font-weight:800;">${this._esc(label)}</a>`;

    const endpoints = diag.endpoints || {};
    const links = [
      { name: 'Diagnostics (this)', url: endpoints.diagnostics || '/api/roamcore/diagnostics' },
      { name: 'OpenClaw summary', url: endpoints.openclaw_summary || '/api/roamcore/openclaw/summary' },
      { name: 'OpenClaw skill', url: endpoints.openclaw_skill || '/api/roamcore/openclaw/skill' },
      { name: 'OpenClaw rc_dump', url: endpoints.openclaw_rc_dump || '/api/roamcore/openclaw/rc_dump' },
      { name: 'OpenClaw timeseries catalog', url: endpoints.openclaw_timeseries_catalog || '/api/roamcore/openclaw/timeseries/catalog' },
      { name: 'OpenClaw timeseries', url: endpoints.openclaw_timeseries || '/api/roamcore/openclaw/timeseries' },
    ];

    const roamcoreVer = diag?.roamcore?.component_version || '—';
    const hassVer = diag?.hass?.version || '—';

    const provisioned = pm.exists === true;
    const installInfoExists = ii.exists === true;

    const installParsed = ii.parsed || {};
    const pmParsed = pm.parsed || {};

    const installLines = Object.keys(installParsed).length
      ? Object.keys(installParsed).sort().map(k => this._row(k, this._esc(installParsed[k]))).join('')
      : '<div class="rc-mini">No install-info keys found.</div>';

    const pmLines = Object.keys(pmParsed).length
      ? Object.keys(pmParsed).sort().map(k => this._row(k, this._esc(pmParsed[k]))).join('')
      : '<div class="rc-mini">No provision marker keys found.</div>';

    const readyBadges = `
      <div class="rc-pillrow2">
        ${this._presenceBadge('Owner', 'binary_sensor.rc_setup_owner_ready')}
        ${this._presenceBadge('Map', 'binary_sensor.rc_setup_map_ready')}
        ${this._presenceBadge('Trip Wrapped', 'binary_sensor.rc_setup_trip_wrapped_ready')}
        ${this._presenceBadge('Victron', 'binary_sensor.rc_setup_victron_ready')}
        ${this._presenceBadge('Power backend', 'binary_sensor.rc_system_power_backend_connected')}
      </div>
    `;

    const entityRows = (keyEntities && keyEntities.length)
      ? keyEntities.slice(0, 40).map(e => {
          const ok = e?.exists === true;
          const st = e?.state;
          const status = !ok ? 'inactive' : (st === 'unknown' || st === 'unavailable') ? 'inactive' : 'ok';
          const label = ok ? 'Present' : 'Missing';
          return `
            <div class="rc-row" style="gap:12px; align-items:flex-start;">
              <div style="min-width: 0; flex:1;">
                <div style="font-weight:900; font-size:12px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${this._esc(e.entity_id)}</div>
                <div class="rc-mini" style="margin-top:4px;">state: ${this._esc(st)}</div>
              </div>
              <div>${this._badge(label, status)}</div>
            </div>
          `;
        }).join('')
      : '<div class="rc-mini">Key entity list unavailable (still loading or endpoint failed).</div>';

    const copyBtnLabel = this._diagLoading ? 'Loading…' : 'Copy JSON support bundle';

    this._root.innerHTML = `
      <div class="rc-page">
        ${this._header('Diagnostics')}

        <div class="rc-grid">
          ${this._tile({
            title: 'Install & Provisioning',
            icon: '🧩',
            content: `
              ${this._row('RoamCore component', roamcoreVer)}
              ${this._row('Home Assistant', hassVer)}
              ${this._row('Auto-provision enabled', String(opts.auto_provision_assets ?? '—'))}
              ${this._row('Provision ref', String(opts.provision_ref ?? '—'))}
              <div style="margin-top:10px;" class="rc-mini">install-info.txt: ${installInfoExists ? '<span style=\"color:var(--rc-good);font-weight:900\">found</span>' : '<span style=\"color:var(--rc-bad);font-weight:900\">missing</span>'}</div>
              <div style="margin-top:6px;" class="rc-kv">${installLines}</div>
              <div style="margin-top:10px;" class="rc-mini">provisioned.marker: ${provisioned ? '<span style=\"color:var(--rc-good);font-weight:900\">found</span>' : '<span style=\"color:var(--rc-bad);font-weight:900\">missing</span>'}</div>
              <div style="margin-top:6px;" class="rc-kv">${pmLines}</div>
            `
          })}

          ${this._tile({
            title: 'Readiness',
            icon: '✅',
            content: `
              <div class="rc-label">These indicate whether the setup wizard / core backends are ready.</div>
              ${this._row('Setup progress', this._getState('sensor.rc_setup_progress'))}
              ${readyBadges}
              <div style="display:flex; gap:10px; margin-top: 12px;">
                <button class="rc-btn2" id="rcDiagRefresh" ${this._diagLoading ? 'disabled' : ''}>Refresh</button>
                <button class="rc-btn2" data-nav="${this._basePath()}/status">Open status view</button>
              </div>
              ${this._diagErr ? `<div style="margin-top:10px; color: var(--rc-bad); font-weight:800;">${this._esc(this._diagErr)}</div>` : ''}
            `
          })}

          ${this._tile({
            title: 'Key entities (presence + state)',
            icon: '🧾',
            className: 'span-2',
            content: `
              <div class="rc-label">If something is missing, verify packages are loaded and entity IDs match the RoamCore contract.</div>
              ${entityRows}
            `
          })}

          ${this._tile({
            title: 'OpenClaw API',
            icon: '🤖',
            content: `
              <div class="rc-label">Quick links (same-origin). Open in a new tab to view raw JSON.</div>
              <div style="margin-top:10px;">
                ${links.map(l => `
                  <div class="rc-linkrow">
                    <div style="min-width:0; flex:1;">
                      <div class="rc-linkname">${openLink(l.url, l.name)}</div>
                      <div class="rc-link">${this._esc(l.url)}</div>
                    </div>
                    <button class="rc-btn2" data-copy-url="${this._esc(l.url)}">Copy</button>
                  </div>
                `).join('')}
              </div>
            `
          })}

          ${this._tile({
            title: 'Support bundle',
            icon: '📋',
            content: `
              <div class="rc-label">Copy a JSON bundle (includes install/provision info and rc_* state dump) and paste into a support ticket.</div>
              <div style="display:flex; gap:10px; margin-top:12px; flex-wrap:wrap;">
                <button class="rc-btn2" id="rcCopyBundle" ${this._diagLoading ? 'disabled' : ''}>${this._esc(copyBtnLabel)}</button>
                <a class="rc-btn2" href="https://github.com/roamcore/RoamCore/issues" target="_blank" rel="noreferrer" title="Open GitHub issues" style="opacity:0.85; text-decoration:none;">Support</a>
              </div>
              ${this._copyStatus ? `<div style="margin-top:10px; font-weight:800;">${this._esc(this._copyStatus)}</div>` : ''}
              <div style="margin-top:10px;" class="rc-mini">Tip: if clipboard is blocked (some WebViews), open the dashboard in a normal browser and try again.</div>
            `,
            className: 'span-2'
          })}
        </div>
      </div>
    `;

    // Wire buttons
    const refresh = this._root.querySelector('#rcDiagRefresh');
    if (refresh) refresh.addEventListener('click', () => this._fetchDiagnostics({ force: true }));

    const copyBtn = this._root.querySelector('#rcCopyBundle');
    if (copyBtn) copyBtn.addEventListener('click', () => this._copyBundle());

    // Copy link buttons
    const copyEls = this._root.querySelectorAll('[data-copy-url]');
    copyEls.forEach((el) => {
      el.addEventListener('click', async (ev) => {
        try {
          const url = el.getAttribute('data-copy-url');
          const ok = await this._copyText(url);
          this._copyStatus = ok ? 'Copied link to clipboard.' : 'Copy failed.';
          this._render();
        } catch (e) {}
      });
    });
  }
}

function round1(n){
  try{ return (Math.round(Number(n)*10)/10).toFixed(1).replace(/\.0$/,''); }catch(e){return n}
}
customElements.define('roamcore-network-page', RoamcoreNetworkPage);
customElements.define('roamcore-level-page', RoamcoreLevelPage);
customElements.define('roamcore-map-page', RoamcoreMapPage);
customElements.define('roamcore-location-page', RoamcoreLocationPage);
customElements.define('roamcore-setup-page', RoamcoreSetupPage);
customElements.define('roamcore-settings-page', RoamcoreSettingsPage);
customElements.define('roamcore-diagnostics-page', RoamcoreDiagnosticsPage);

// --- Victron connect card (bundled for reliability) ---
// The dashboard references `custom:roamcore-victron-connect`. If the user forgets
// to add roamcore-victron-connect.js as a Lovelace resource, the card won't load.
// To make first-run installs more reliable, we bundle the card definition here as
// well. (Keeping the standalone file is fine; we guard against double-define.)
try {
  if (!customElements.get('roamcore-victron-connect')) {
    class RoamCoreVictronConnectCard extends HTMLElement {
      constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this._config = {};
        this._hass = null;
        this._candidates = [];
        this._loading = false;
        this._connecting = false;
        this._error = null;
        this._success = null;
        this._status = null;
        this._statusPollTimer = null;
        this._statusPollInFlight = false;
        this._manualHost = '';
        this._manualPort = 1883;
        this._manualTls = false;
        this._manualPortTouched = false;
      }

      connectedCallback() {
        // Keep status reasonably fresh without requiring manual clicks.
        // Best-effort + low frequency to avoid hammering HA/Supervisor.
        if (!this._statusPollTimer) {
          try { this._fetchStatus(); } catch (e) {}
          this._statusPollTimer = setInterval(() => {
            try { this._fetchStatus(); } catch (e) {}
          }, 10000);
        }
      }

      disconnectedCallback() {
        if (this._statusPollTimer) {
          clearInterval(this._statusPollTimer);
          this._statusPollTimer = null;
        }
      }

      setConfig(config) {
        this._config = config || {};
        this._render();
      }

      set hass(hass) {
        this._hass = hass;
        if (this._candidates.length === 0 && !this._loading) this._discover();
      }

      _getApiBase() {
        if (this._config.api_base) return this._config.api_base;
        try {
          const panels = this._hass?.panels || {};
          for (const key of Object.keys(panels)) {
            const p = panels[key];
            const title = String(p?.title || p?.config?.title || '').toLowerCase();
            const urlPath = String(p?.url_path || '').toLowerCase();
            const ingress = p?.config?.ingress;
            const isVictron = title.includes('victron') || title.includes('venus') || urlPath.includes('victron');
            if (isVictron && ingress) return `/api/hassio_ingress/${ingress}`;
          }
        } catch (e) {}
        return '/api/hassio_ingress/roamcore_victron_auto_dev';
      }

      async _fetchStatus() {
        if (this._statusPollInFlight) return;
        try {
          this._statusPollInFlight = true;
          const base = this._getApiBase();
          const ctl = new AbortController();
          // Status is best-effort, but can be slow on loaded HA boxes.
          const t = setTimeout(() => ctl.abort(), 4000);
          const resp = await fetch(`${base}/api/v1/victron/status`, { credentials: 'same-origin', signal: ctl.signal })
            .finally(() => clearTimeout(t));
          if (!resp.ok) throw new Error(`status ${resp.status}`);
          const data = await resp.json().catch(() => ({}));
          this._status = (data && data.status) ? data.status : data;
          this._render();
        } catch (e) {
          // ignore (status is best-effort)
        } finally {
          this._statusPollInFlight = false;
        }
      }

      async _discover() {
        this._loading = true;
        this._error = null;
        this._render();
        try {
          const base = this._getApiBase();
          const ctl = new AbortController();
          // Discovery may involve mDNS/DNS probes inside the add-on; keep this lenient.
          const t = setTimeout(() => ctl.abort(), 8000);
          const resp = await fetch(`${base}/api/v1/victron/discover`, { credentials: 'same-origin', signal: ctl.signal })
            .finally(() => clearTimeout(t));
          if (!resp.ok) throw new Error(`Discovery failed: ${resp.status} ${resp.statusText}`);
          const data = await resp.json();
          this._candidates = (data.candidates || []).slice();
          try {
            this._candidates.sort((a, b) => {
              const ar = a && a.reachable === true;
              const br = b && b.reachable === true;
              if (ar !== br) return ar ? -1 : 1;
              const ab = a && a.bad === true;
              const bb = b && b.bad === true;
              if (ab !== bb) return ab ? 1 : -1;
              return 0;
            });
          } catch (e) {}
          if (this._candidates.length === 0) {
            this._error = 'No Victron devices found on the network. Make sure your GX device is powered on and connected.';
          }
        } catch (err) {
          if (err && (err.name === 'AbortError' || String(err.message || '').includes('aborted'))) {
            this._error = 'Discovery timed out. Check network/Victron power and try again.';
          } else {
            this._error = `Discovery error: ${err?.message || err}`;
          }
          this._candidates = [];
        } finally {
          this._loading = false;
          this._render();
        }
      }

      async _connect(candidate) {
        this._connecting = true;
        this._error = null;
        this._success = null;
        this._render();
        try {
          const base = this._getApiBase();
          const ctl = new AbortController();
          const t = setTimeout(() => ctl.abort(), 8000);
          const resp = await fetch(`${base}/api/v1/victron/connect`, {
            method: 'POST',
            credentials: 'same-origin',
            signal: ctl.signal,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              host: candidate.host || candidate.ip,
              port: candidate.port || 1883,
              use_tls: candidate.use_tls || false,
              portal_id: candidate.portal_id || null,
            }),
          }).finally(() => clearTimeout(t));
          if (!resp.ok) {
            const errData = await resp.json().catch(() => ({}));
            throw new Error(errData.error || `Connect failed: ${resp.status}`);
          }
          const data = await resp.json().catch(() => ({}));
          this._success = data.message || 'Connected! The add-on is restarting to apply the configuration.';
          this._candidates = [];
          try {
            this._status = null;
            setTimeout(() => this._fetchStatus(), 800);
            setTimeout(() => this._fetchStatus(), 2500);
          } catch (e) {}
        } catch (err) {
          if (err && (err.name === 'AbortError' || String(err.message || '').includes('aborted'))) {
            this._error = 'Connection timed out. Check the GX is reachable on the LAN (MQTT port 1883/8883) and try again.';
          } else {
            this._error = `Connection error: ${err?.message || err}`;
          }
        } finally {
          this._connecting = false;
          this._render();
        }
      }

      async _connectManual() {
        const host = String(this._manualHost || '').trim();
        const port = parseInt(String(this._manualPort || '1883'), 10) || 1883;
        const use_tls = !!this._manualTls;
        if (!host) {
          this._error = 'Enter a host (IP or hostname) to connect.';
          this._success = null;
          this._render();
          return;
        }
        return this._connect({ host, port, use_tls, source: 'manual' });
      }

      async _clear() {
        this._connecting = true;
        this._error = null;
        this._success = null;
        this._render();
        try {
          const base = this._getApiBase();
          const ctl = new AbortController();
          const t = setTimeout(() => ctl.abort(), 8000);
          const resp = await fetch(`${base}/api/v1/victron/clear`, {
            method: 'POST',
            credentials: 'same-origin',
            signal: ctl.signal,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({}),
          }).finally(() => clearTimeout(t));
          if (!resp.ok) {
            const errData = await resp.json().catch(() => ({}));
            throw new Error(errData.error || `Clear failed: ${resp.status}`);
          }
          const data = await resp.json().catch(() => ({}));
          this._success = data.message || 'Cleared configuration. The add-on may restart.';
          this._candidates = [];
        } catch (err) {
          if (err && (err.name === 'AbortError' || String(err.message || '').includes('aborted'))) {
            this._error = 'Clear timed out. Try again; the add-on may be restarting.';
          } else {
            this._error = `Clear error: ${err?.message || err}`;
          }
        } finally {
          this._connecting = false;
          this._render();
        }
      }

      _escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = String(str ?? '');
        return div.innerHTML;
      }

      _render() {
        const title = this._config.title || 'Connect Victron Device';
        const st = this._status || null;
        const stConfigValid = st && st.config ? st.config.valid === true : null;
        const stVic = st && st.victron ? st.victron : null;
        const stInv = st && st.inventory ? st.inventory : null;
        const statusLine = (stConfigValid == null && !stVic && !stInv)
          ? ''
          : `
            <div style="margin: 10px 0 14px; padding: 10px 12px; border: 1px solid var(--divider-color); border-radius: 10px; background: rgba(255,255,255,0.02);">
              <div style="font-weight: 800; margin-bottom: 6px;">Status</div>
              <div style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 12px; opacity: 0.9;">
                ${stConfigValid == null ? '' : `config.valid=${stConfigValid}<br/>`}
                ${stVic ? `victron.connected=${stVic.connected === true}<br/>did_full_publish=${stVic.did_full_publish === true}<br/>` : ''}
                ${stInv ? `devices=${stInv.devices_count || 0} topics=${stInv.topics_count || 0}` : ''}
              </div>
            </div>
          `;
        this.shadowRoot.innerHTML = `
          <style>
            :host { display:block; }
            ha-card { padding: 16px; }
            .header{ display:flex; align-items:center; justify-content:space-between; margin-bottom: 16px; }
            .title{ font-size: 1.2em; font-weight: 600; color: var(--primary-text-color); }
            .refresh-btn{ background:none; border:none; cursor:pointer; padding:8px; border-radius:50%; color: var(--primary-color); }
            .refresh-btn:hover{ background: var(--secondary-background-color); }
            .refresh-btn:disabled{ opacity: 0.5; cursor: not-allowed; }
            .btn-row{ display:flex; gap:10px; justify-content:flex-end; margin: -6px 0 12px; }
            .btn{ border: 1px solid var(--divider-color); background: var(--secondary-background-color); color: var(--primary-text-color);
                  padding: 8px 10px; border-radius: 10px; cursor: pointer; font-weight: 700; }
            .btn:disabled{ opacity:0.5; cursor:not-allowed; }
            .btn-danger{ border-color: color-mix(in srgb, var(--error-color, #b00020) 55%, var(--divider-color)); }
            .loading{ text-align:center; padding: 24px; color: var(--secondary-text-color); }
            .spinner{ display:inline-block; width: 24px; height: 24px; border: 3px solid var(--divider-color); border-top-color: var(--primary-color);
                      border-radius: 50%; animation: spin 1s linear infinite; }
            @keyframes spin { to { transform: rotate(360deg); } }
            .error{ background: var(--error-color, #b00020); color:#fff; padding: 12px; border-radius: 8px; margin-bottom: 16px; }
            .success{ background: var(--success-color, #4caf50); color:#fff; padding: 12px; border-radius: 8px; margin-bottom: 16px; }
            .candidates{ display:flex; flex-direction:column; gap: 8px; }
            .candidate{ display:flex; align-items:center; justify-content:space-between; padding: 12px 16px; background: var(--secondary-background-color);
                        border-radius: 8px; cursor:pointer; transition: background .2s; }
            .candidate.bad{ opacity: 0.55; cursor: not-allowed; }
            .candidate.unreachable{ opacity: 0.72; }
            .candidate:hover{ background: var(--primary-color); color: var(--text-primary-color, white); }
            .candidate.bad:hover{ background: var(--secondary-background-color); color: inherit; }
            .candidate:hover .candidate-source{ color: inherit; opacity: 0.8; }
            .candidate-host{ font-family: monospace; font-size: 0.9em; }
            .candidate-source{ font-size: 0.8em; color: var(--secondary-text-color); margin-top: 2px; }
            .empty{ text-align:center; padding: 24px; color: var(--secondary-text-color); }
            .empty-icon{ font-size: 48px; margin-bottom: 8px; }

            .manual{ margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--divider-color); }
            .manual-title{ font-weight: 800; margin-bottom: 8px; }
            .manual-row{ display:flex; gap: 10px; align-items:center; flex-wrap: wrap; }
            .manual-row input{ padding: 8px 10px; border-radius: 10px; border: 1px solid var(--divider-color);
                               background: var(--secondary-background-color); color: var(--primary-text-color); }
            .manual-row input.host{ flex: 1; min-width: 200px; }
            .manual-row input.port{ width: 96px; }
            .manual-row label{ display:inline-flex; gap: 8px; align-items:center; font-weight: 700; opacity: 0.9; }
          </style>

          <ha-card>
            <div class="header">
              <span class="title">${this._escapeHtml(title)}</span>
              <button class="refresh-btn" ${this._loading || this._connecting ? 'disabled' : ''}>
                <ha-icon icon="mdi:refresh"></ha-icon>
              </button>
            </div>

            <div class="btn-row">
              <button class="btn" id="statusBtn" ${this._loading || this._connecting ? 'disabled' : ''}>Status</button>
              <button class="btn btn-danger" id="clearBtn" ${this._loading || this._connecting ? 'disabled' : ''}>Clear</button>
            </div>

            ${statusLine}

            ${this._error ? `<div class="error">${this._escapeHtml(this._error)}</div>` : ''}
            ${this._success ? `<div class="success">${this._escapeHtml(this._success)}</div>` : ''}

            ${this._loading ? `
              <div class="loading"><div class="spinner"></div><p>Discovering Victron devices...</p></div>
            ` : this._connecting ? `
              <div class="loading"><div class="spinner"></div><p>Connecting...</p></div>
            ` : this._candidates.length > 0 ? `
              <div class="candidates">
                ${this._candidates.map((c, i) => `
                  <div class="candidate ${c.bad ? 'bad' : ''} ${c.reachable === false ? 'unreachable' : ''}" data-index="${i}">
                    <div class="candidate-info">
                      <div class="candidate-name">${this._escapeHtml(c.name || 'Victron Device')}</div>
                      <div class="candidate-host">${this._escapeHtml(c.host || c.ip)}:${c.port || 1883}</div>
                      <div class="candidate-source">${this._escapeHtml(c.source || 'unknown')}${c.reachable === true ? ' (reachable)' : c.reachable === false ? ' (unreachable)' : ''}${c.bad ? ' (bad)' : ''}</div>
                    </div>
                    <div class="candidate-action"><ha-icon icon="mdi:chevron-right"></ha-icon></div>
                  </div>
                `).join('')}
              </div>
            ` : (!this._success ? `
              <div class="empty"><div class="empty-icon">🔍</div><p>No devices found</p><p>Tap refresh to scan again.</p></div>
            ` : '')}

            <div class="manual">
              <div class="manual-title">Manual connect</div>
              <div class="manual-row">
                <input class="host" id="manualHost" placeholder="GX host (e.g. 192.168.1.50 or venus.local)" value="${this._escapeHtml(this._manualHost || '')}" />
                <input class="port" id="manualPort" type="number" min="1" max="65535" value="${Number(this._manualPort || 1883)}" />
                <label><input id="manualTls" type="checkbox" ${this._manualTls ? 'checked' : ''}/> TLS</label>
                <button class="btn" id="manualConnectBtn" ${this._loading || this._connecting ? 'disabled' : ''}>Connect</button>
              </div>
              <div style="margin-top:8px; font-size:12px; opacity:0.8;">Default MQTT ports: 1883 (no TLS) / 8883 (TLS).</div>
            </div>
          </ha-card>
        `;

        const refreshBtn = this.shadowRoot.querySelector('.refresh-btn');
        if (refreshBtn) refreshBtn.addEventListener('click', () => this._discover());
        const statusBtn = this.shadowRoot.querySelector('#statusBtn');
        if (statusBtn) statusBtn.addEventListener('click', () => this._fetchStatus());
        const clearBtn = this.shadowRoot.querySelector('#clearBtn');
        if (clearBtn) clearBtn.addEventListener('click', () => {
          const ok = window.confirm('Clear Victron configuration? This will disconnect and may restart the add-on.');
          if (ok) this._clear();
        });
        const candidateEls = this.shadowRoot.querySelectorAll('.candidate');
        candidateEls.forEach(el => el.addEventListener('click', () => {
          const idx = parseInt(el.dataset.index, 10);
          const c = this._candidates[idx];
          if (c && !c.bad) this._connect(c);
        }));

        const manualHostEl = this.shadowRoot.querySelector('#manualHost');
        if (manualHostEl) manualHostEl.addEventListener('input', () => { this._manualHost = manualHostEl.value; });
        const manualPortEl = this.shadowRoot.querySelector('#manualPort');
        if (manualPortEl) manualPortEl.addEventListener('input', () => {
          this._manualPort = manualPortEl.value;
          this._manualPortTouched = true;
        });
        const manualTlsEl = this.shadowRoot.querySelector('#manualTls');
        if (manualTlsEl) manualTlsEl.addEventListener('change', () => {
          this._manualTls = !!manualTlsEl.checked;
          if (!this._manualPortTouched) {
            this._manualPort = this._manualTls ? 8883 : 1883;
            // Avoid a full re-render (can steal focus); just update the input.
            try {
              const portEl = this.shadowRoot.querySelector('#manualPort');
              if (portEl) portEl.value = String(this._manualPort);
            } catch (e) {}
          }
        });
        const manualConnectBtn = this.shadowRoot.querySelector('#manualConnectBtn');
        if (manualConnectBtn) manualConnectBtn.addEventListener('click', () => this._connectManual());

        // Keyboard UX
        if (manualHostEl) manualHostEl.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') this._connectManual(); });
        if (manualPortEl) manualPortEl.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') this._connectManual(); });
      }

      getCardSize() { return 3; }
      static getStubConfig() { return { title: 'Connect Victron Device' }; }
    }

    customElements.define('roamcore-victron-connect', RoamCoreVictronConnectCard);
    window.customCards = window.customCards || [];
    window.customCards.push({
      type: 'roamcore-victron-connect',
      name: 'RoamCore Victron Connect',
      description: 'Discover and connect to Victron devices on your network',
      preview: true,
    });
  }
} catch (e) {
  // ignore
}
